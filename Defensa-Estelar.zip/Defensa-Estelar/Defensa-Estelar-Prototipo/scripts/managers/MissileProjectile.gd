## MissileProjectile.gd
## Explota al impactar, dañando a todos los enemigos dentro del radio.
class_name MissileProjectile
extends Projectile

var _radio_explosion: float = 60.0

func init(objetivo: Node2D, dano: float, color: Color, velocidad: float,
		radio: float = 60.0) -> void:
	super.init(objetivo, dano, color, velocidad)
	_radio_explosion = radio

func _al_impactar() -> void:
	_explotar()
	_reproducir_impacto()
	_volver_al_pool()

func _explotar() -> void:
	var enemigos: Array = get_tree().get_nodes_in_group("enemies")
	for enemigo in enemigos:
		if not is_instance_valid(enemigo): continue
		if not (enemigo as Enemy).is_alive(): continue
		var dist: float = (enemigo as Node2D).global_position.distance_to(global_position)
		if dist <= _radio_explosion:
			# Reducción de daño: completo en el centro, mitad en el borde
			var reduccion: float = 1.0 - (dist / _radio_explosion) * 0.5
			(enemigo as Enemy).take_damage(_dano * reduccion)
	_visual_explosion()

func _visual_explosion() -> void:
	var circulo := Node2D.new()
	get_parent().add_child(circulo)
	circulo.global_position = global_position
	var tween := circulo.create_tween()
	circulo.draw.connect(func():
		circulo.draw_circle(Vector2.ZERO, _radio_explosion, Color(_color, 0.3))
		circulo.draw_arc(Vector2.ZERO, _radio_explosion, 0, TAU, 32, Color(_color, 0.8), 2.0)
	)
	tween.tween_property(circulo, "modulate:a", 0.0, 0.35)
	tween.tween_callback(circulo.queue_free)
