## Projectile.gd
## Clase base para todos los proyectiles. Se poolea via ObjectPool.
## Persigue al objetivo hasta el impacto o hasta salir del rango.
class_name Projectile
extends Node2D

var _objetivo: Node2D    = null
var _dano: float         = 10.0
var _velocidad: float    = 300.0
var _color: Color        = Color.WHITE
var _rango_max: float    = 600.0
var _origen: Vector2     = Vector2.ZERO
var _recorrido: float    = 0.0

@onready var sprite: Sprite2D = $Sprite2D

# ─── Inicialización (llamado tras recuperar del pool) ─────────────────────
func init(objetivo: Node2D, dano: float, color: Color, velocidad: float) -> void:
	_objetivo   = objetivo
	_dano       = dano
	_color      = color
	_velocidad  = velocidad
	_origen     = global_position
	_recorrido  = 0.0
	if sprite: sprite.modulate = color

# ─── Movimiento ────────────────────────────────────────────────────────────
func _physics_process(delta: float) -> void:
	if not visible: return

	if _objetivo == null or not is_instance_valid(_objetivo) or not _objetivo.is_alive():
		_volver_al_pool(); return

	var dir: Vector2  = (_objetivo.global_position - global_position).normalized()
	var paso: float   = _velocidad * delta
	global_position  += dir * paso
	rotation          = dir.angle() + PI / 2.0
	_recorrido       += paso

	if global_position.distance_to(_objetivo.global_position) <= 8.0:
		_al_impactar()
	elif _recorrido > _rango_max:
		_volver_al_pool()

func _al_impactar() -> void:
	if _objetivo and is_instance_valid(_objetivo) and _objetivo.is_alive():
		_objetivo.take_damage(_dano)
	_reproducir_impacto()
	_volver_al_pool()

func _reproducir_impacto() -> void:
	pass  # Sobreescribir para efectos visuales

func _volver_al_pool() -> void:
	ObjectPool.return_object(self)
