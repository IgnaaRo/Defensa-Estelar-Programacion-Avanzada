## WaveManager.gd — Controla el spawn y progresión de oleadas
class_name WaveManager
extends Node

signal wave_started(wave_num: int)
signal wave_completed(wave_num: int)
signal all_waves_completed()

const RUTAS_ENEMIGOS := {
	"scout":   "res://scenes/enemies/AlienScout.tscn",
	"warrior": "res://scenes/enemies/AlienWarrior.tscn",
	"armored": "res://scenes/enemies/AlienArmored.tscn",
	"flyer":   "res://scenes/enemies/AlienFlyer.tscn",
	"boss":    "res://scenes/enemies/ColossalBoss.tscn",
}

@export var intervalo_spawn: float = 0.8

var path_points: PackedVector2Array = []
var enemy_parent: Node = null

var _cola_oleada: Array[Dictionary] = []
var _enemigos_activos: int = 0
var _oleada_en_progreso: bool = false
var _timer_spawn: float = 0.0
var _indice_spawn: int = 0
var _esperando_limpieza: bool = false

# ── Composición de oleadas ──────────────────────────────────────────────────
func _construir_oleada(n: int) -> Array[Dictionary]:
	var grupos: Array[Dictionary] = []
	if n % 5 == 0:   # oleada de jefe
		grupos.append({"tipo":"scout",   "cantidad":4, "delay":0.6})
		grupos.append({"tipo":"warrior", "cantidad":3, "delay":0.8})
		grupos.append({"tipo":"boss",    "cantidad":1, "delay":2.5})
		return grupos
	if n <= 3:
		grupos.append({"tipo":"scout",   "cantidad":3 + n,          "delay":0.7})
	elif n <= 6:
		grupos.append({"tipo":"scout",   "cantidad":4,               "delay":0.6})
		grupos.append({"tipo":"warrior", "cantidad":n - 2,           "delay":0.9})
	elif n <= 10:
		grupos.append({"tipo":"warrior", "cantidad":n,               "delay":0.8})
		# FIX: usar max(1, ...) y conversión explícita a int para evitar floats
		grupos.append({"tipo":"armored", "cantidad":max(1, int((n - 6) / 2)), "delay":1.5})
		if n >= 8:
			grupos.append({"tipo":"flyer","cantidad":2,              "delay":0.7})
	elif n <= 15:
		grupos.append({"tipo":"warrior", "cantidad":n - 2,           "delay":0.7})
		grupos.append({"tipo":"armored", "cantidad":max(1, int(n / 3)), "delay":1.2})
		grupos.append({"tipo":"flyer",   "cantidad":max(1, int(n / 4)), "delay":0.6})
	else:
		grupos.append({"tipo":"scout",   "cantidad":6,               "delay":0.4})
		grupos.append({"tipo":"warrior", "cantidad":n,               "delay":0.65})
		grupos.append({"tipo":"armored", "cantidad":max(1, int(n / 2)), "delay":1.0})
		grupos.append({"tipo":"flyer",   "cantidad":max(1, int(n / 3)), "delay":0.5})
	return grupos

# ── API pública ──────────────────────────────────────────────────────────────
func start_wave() -> void:
	if _oleada_en_progreso: return
	GameManager.advance_wave()
	var num_oleada: int = GameManager.current_wave

	_cola_oleada = []
	for grupo in _construir_oleada(num_oleada):
		for i in int(grupo["cantidad"]):
			_cola_oleada.append({"tipo": grupo["tipo"], "delay": grupo["delay"]})

	_indice_spawn        = 0
	_enemigos_activos    = 0
	_oleada_en_progreso  = true
	_esperando_limpieza  = false
	_timer_spawn         = 0.4
	wave_started.emit(num_oleada)

func notify_enemy_removed() -> void:
	_enemigos_activos = max(0, _enemigos_activos - 1)
	_verificar_completada()

func is_wave_in_progress() -> bool:
	return _oleada_en_progreso

# ── Interno ──────────────────────────────────────────────────────────────────
func _process(delta: float) -> void:
	if not _oleada_en_progreso or _esperando_limpieza: return
	if _indice_spawn >= _cola_oleada.size():
		_esperando_limpieza = true; return

	_timer_spawn -= delta
	if _timer_spawn > 0.0: return

	var entrada: Dictionary = _cola_oleada[_indice_spawn]
	_spawnear(entrada["tipo"])
	_timer_spawn  = entrada["delay"]
	_indice_spawn += 1

func _spawnear(tipo: String) -> void:
	if enemy_parent == null: return
	var ruta: String = RUTAS_ENEMIGOS.get(tipo, "")
	if ruta == "": return
	var escena: PackedScene = load(ruta) as PackedScene
	if escena == null: return
	var enemigo: Enemy = escena.instantiate() as Enemy
	enemy_parent.add_child(enemigo)
	enemigo.init_path(path_points)
	enemigo.enemy_died.connect(func(_e, _r): notify_enemy_removed())
	enemigo.enemy_reached_end.connect(func(_e): notify_enemy_removed())
	_enemigos_activos += 1

func _verificar_completada() -> void:
	if _esperando_limpieza and _enemigos_activos <= 0:
		_oleada_en_progreso = false
		_esperando_limpieza = false
		wave_completed.emit(GameManager.current_wave)
		GameManager.add_tech_points(1 + GameManager.current_wave / 5)

		if not GameManager.is_infinite_mode and GameManager.current_wave >= GameManager.total_waves:
			all_waves_completed.emit()
