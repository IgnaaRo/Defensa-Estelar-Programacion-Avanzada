## CryoProjectile.gd
## Aplica efecto de ralentización al impactar.
class_name CryoProjectile
extends Projectile

var _mult_slow: float      = 0.5
var _duracion_slow: float  = 1.5

func init(objetivo: Node2D, dano: float, color: Color, velocidad: float,
		mult_slow: float = 0.5, dur_slow: float = 1.5) -> void:
	super.init(objetivo, dano, color, velocidad)
	_mult_slow     = mult_slow
	_duracion_slow = dur_slow

func _al_impactar() -> void:
	if _objetivo and is_instance_valid(_objetivo) and _objetivo.is_alive():
		_objetivo.take_damage(_dano)
		_objetivo.apply_slow(_mult_slow, _duracion_slow)
	_reproducir_impacto()
	_volver_al_pool()
