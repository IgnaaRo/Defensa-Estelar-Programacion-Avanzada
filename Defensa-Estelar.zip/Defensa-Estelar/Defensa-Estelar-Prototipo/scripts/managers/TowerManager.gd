## TowerManager.gd
## Gestiona los slots de torres, construcción, mejora y venta.
class_name TowerManager
extends Node

signal tower_built(torre: Tower, slot: Node2D)
signal tower_upgraded(torre: Tower)
signal tower_sold(torre: Tower)
signal tower_selected(torre: Tower)
signal tower_deselected()

const ESCENAS_TORRES := {
	Tower.TowerType.LASER:   "res://scenes/towers/LaserTower.tscn",
	Tower.TowerType.PLASMA:  "res://scenes/towers/PlasmaTower.tscn",
	Tower.TowerType.CRYO:    "res://scenes/towers/CryoTower.tscn",
	Tower.TowerType.MISSILE: "res://scenes/towers/MissileTower.tscn",
}

const COSTOS_TORRES := {
	Tower.TowerType.LASER:   80,
	Tower.TowerType.PLASMA:  150,
	Tower.TowerType.CRYO:    100,
	Tower.TowerType.MISSILE: 130,
}

var _slots: Array[Node2D]    = []
var _slot_torres: Dictionary = {}
var _selected_tower: Tower   = null
var _tipo_seleccionado: int  = -1

func register_slots(slots: Array[Node2D]) -> void:
	_slots      = slots
	_slot_torres = {}
	for slot in _slots:
		_slot_torres[slot] = null
		if slot.has_signal("slot_clicked"):
			slot.connect("slot_clicked", _al_clickear_slot)

func limpiar_torres() -> void:
	for slot in _slots:
		if _slot_torres.get(slot) != null:
			_slot_torres[slot].queue_free()
			_slot_torres[slot] = null

func queue_build(tipo_torre: int) -> void:
	if not GameManager.can_afford(COSTOS_TORRES.get(tipo_torre, 0)): return
	_tipo_seleccionado = tipo_torre
	_selected_tower    = null
	tower_deselected.emit()

func cancelar_construccion() -> void:
	_tipo_seleccionado = -1

func _al_clickear_slot(slot: Node2D) -> void:
	var existente: Tower = _slot_torres.get(slot, null)
	if existente != null:
		if _selected_tower == existente:
			_deseleccionar_torre()
		else:
			_seleccionar_torre(existente)
		_tipo_seleccionado = -1
		return
	if _tipo_seleccionado >= 0:
		_construir_torre_en_slot(slot, _tipo_seleccionado)
		_tipo_seleccionado = -1

func _construir_torre_en_slot(slot: Node2D, tipo: int) -> void:
	var costo: int = COSTOS_TORRES.get(tipo, 0) as int
	if not GameManager.spend_resources(costo): return
	var ruta: String = ESCENAS_TORRES.get(tipo, "")
	if ruta == "": return
	var escena: PackedScene = load(ruta) as PackedScene
	if escena == null: return
	var torre: Tower = escena.instantiate() as Tower
	slot.add_child(torre)
	torre.position = Vector2.ZERO
	torre.tower_selected.connect(_al_seleccionar_torre)
	torre.tower_sold.connect(_al_vender_torre.bind(slot))
	_slot_torres[slot] = torre
	if slot.has_method("set_occupied"):
		slot.set_occupied(true)
	_seleccionar_torre(torre)
	tower_built.emit(torre, slot)

func _seleccionar_torre(torre: Tower) -> void:
	if _selected_tower != null:
		_selected_tower.set_selected(false)
	_selected_tower = torre
	torre.set_selected(true)
	tower_selected.emit(torre)

func _deseleccionar_torre() -> void:
	if _selected_tower != null:
		_selected_tower.set_selected(false)
	_selected_tower = null
	tower_deselected.emit()

func deselect_all() -> void:
	_deseleccionar_torre()
	_tipo_seleccionado = -1

func upgrade_selected() -> bool:
	if _selected_tower == null: return false
	var ok: bool = _selected_tower.upgrade()
	if ok: tower_upgraded.emit(_selected_tower)
	return ok

func sell_selected() -> void:
	if _selected_tower == null: return
	_selected_tower.sell()

func _al_seleccionar_torre(torre: Tower) -> void:
	_seleccionar_torre(torre)

func _al_vender_torre(torre: Tower, slot: Node2D) -> void:
	_slot_torres[slot] = null
	if slot.has_method("set_occupied"):
		slot.set_occupied(false)
	if _selected_tower == torre:
		_selected_tower = null
		tower_deselected.emit()
	tower_sold.emit(torre)

func get_tower_cost(tipo: int) -> int:
	return COSTOS_TORRES.get(tipo, 0)

func can_afford_tower(tipo: int) -> bool:
	return GameManager.can_afford(get_tower_cost(tipo))
