## ResultScreen.gd
## Victory / defeat screen with score, wave reached, and navigation.
extends Control

signal menu_requested()
signal retry_requested()

@onready var title_label:  Label  = %ResultTitle
@onready var score_label:  Label  = %FinalScore
@onready var wave_label:   Label  = %WavesReached
@onready var menu_btn:     Button = %MenuButton
@onready var retry_btn:    Button = %RetryButton

func setup(victory: bool, score: int, waves: int) -> void:
	title_label.text = "COLONY SAVED! 🎉" if victory else "COLONY DESTROYED 💀"
	title_label.modulate = Color(0.3, 1.0, 0.4) if victory else Color(1.0, 0.3, 0.3)
	score_label.text = "Final Score: %d" % score
	wave_label.text  = "Waves Survived: %d" % waves
	menu_btn.pressed.connect(func(): menu_requested.emit())
	retry_btn.pressed.connect(func(): retry_requested.emit())
