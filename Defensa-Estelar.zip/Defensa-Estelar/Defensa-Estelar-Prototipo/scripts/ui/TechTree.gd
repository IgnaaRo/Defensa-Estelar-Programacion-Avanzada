## TechTree.gd
## Research screen shown between levels or via main menu.
extends Control

signal closed()

@onready var tech_points_label: Label      = %TechPointsLabel
@onready var upgrades_grid: GridContainer  = %UpgradesGrid
@onready var close_btn: Button             = %CloseButton

var _upgrade_system: UpgradeSystem

func _ready() -> void:
	_upgrade_system = UpgradeSystem.new()
	add_child(_upgrade_system)
	
	close_btn.pressed.connect(func(): closed.emit())
	GameManager.tech_points_changed.connect(_on_tp_changed)
	_upgrade_system.upgrades_changed.connect(_refresh_grid)
	
	_on_tp_changed(GameManager.tech_points)
	_refresh_grid()

func _on_tp_changed(pts: int) -> void:
	tech_points_label.text = "Tech Points: %d" % pts

func _refresh_grid() -> void:
	for child in upgrades_grid.get_children():
		child.queue_free()
	
	for upg in _upgrade_system.get_all_upgrades():
		var card: Control = _make_upgrade_card(upg)
		upgrades_grid.add_child(card)

func _make_upgrade_card(data: Dictionary) -> Control:
	var panel := PanelContainer.new()
	var vbox  := VBoxContainer.new()
	panel.add_child(vbox)
	
	var icon_name := Label.new()
	icon_name.text = "%s  %s" % [data.get("icon", ""), data.get("name", "")]
	icon_name.add_theme_font_size_override("font_size", 14)
	vbox.add_child(icon_name)
	
	var desc := Label.new()
	desc.text = data.get("desc", "")
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD
	desc.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	vbox.add_child(desc)
	
	var level_lbl := Label.new()
	level_lbl.text = "Level %d / %d" % [data.get("current_level", 0), data.get("max_level", 1)]
	vbox.add_child(level_lbl)
	
	var buy_btn := Button.new()
	buy_btn.text     = "Buy (%d TP)" % data.get("cost", 0)
	buy_btn.disabled = not data.get("can_purchase", false)
	var upg_id: String = data.get("id", "")
	buy_btn.pressed.connect(func():
		_upgrade_system.purchase(upg_id)
	)
	vbox.add_child(buy_btn)
	
	return panel
