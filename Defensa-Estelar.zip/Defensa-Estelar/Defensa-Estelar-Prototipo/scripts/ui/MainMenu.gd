## MainMenu.gd
## Title screen with level select, difficulty, infinite mode, and high scores.
extends Control

# ─── Signals ────────────────────────────────────────────────────────────
signal level_selected(level_idx: int, difficulty: int, infinite: bool)
signal tech_tree_requested()

# ─── Level names ─────────────────────────────────────────────────────────
const LEVEL_NAMES := [
	"1 - Alien Desert",
	"2 - Bioluminescent Forest",
	"3 - Radioactive Canyon",
	"4 - Abandoned Facility",
	"5 - Planet Core",
]

# ─── State ───────────────────────────────────────────────────────────────
var _selected_level: int      = 0
var _selected_difficulty: int = GameManager.Difficulty.NORMAL
var _infinite_mode: bool      = false

# ─── Nodes ───────────────────────────────────────────────────────────────
@onready var level_list: ItemList       = %LevelList
@onready var diff_option: OptionButton  = %DifficultyOption
@onready var infinite_check: CheckBox   = %InfiniteCheck
@onready var play_btn: Button           = %PlayButton
@onready var tech_btn: Button           = %TechButton
@onready var scores_container: VBoxContainer = %ScoresContainer
@onready var title_label: Label         = %TitleLabel
@onready var version_label: Label       = %VersionLabel

func _ready() -> void:
	title_label.text   = "STELLAR DEFENSE"
	version_label.text = "v1.0  |  Anthropic Colony Defense"
	
	_populate_level_list()
	_populate_difficulty()
	_populate_scores()
	
	infinite_check.visible = GameManager.is_infinite_unlocked
	infinite_check.toggled.connect(func(on): _infinite_mode = on)
	
	play_btn.pressed.connect(_on_play_pressed)
	tech_btn.pressed.connect(func(): tech_tree_requested.emit())
	level_list.item_selected.connect(func(idx): _selected_level = idx)
	diff_option.item_selected.connect(func(idx): _selected_difficulty = idx)
	
	# Animate title
	var tween: Tween = create_tween().set_loops()
	tween.tween_property(title_label, "modulate", Color(0.4, 0.9, 1.0), 2.0)
	tween.tween_property(title_label, "modulate", Color(0.8, 0.3, 1.0), 2.0)

func _populate_level_list() -> void:
	for i in LEVEL_NAMES.size():
		level_list.add_item(LEVEL_NAMES[i])
	level_list.select(0)

func _populate_difficulty() -> void:
	diff_option.add_item("Easy")
	diff_option.add_item("Normal")
	diff_option.add_item("Hard")
	diff_option.select(GameManager.Difficulty.NORMAL)

func _populate_scores() -> void:
	for child in scores_container.get_children():
		child.queue_free()
	for i in LEVEL_NAMES.size():
		var key := str(i)
		var score: int = GameManager.high_scores.get(key, 0)
		var lbl := Label.new()
		lbl.text = "%s  —  Best: %d" % [LEVEL_NAMES[i], score]
		scores_container.add_child(lbl)

func _on_play_pressed() -> void:
	level_selected.emit(_selected_level, _selected_difficulty, _infinite_mode)
