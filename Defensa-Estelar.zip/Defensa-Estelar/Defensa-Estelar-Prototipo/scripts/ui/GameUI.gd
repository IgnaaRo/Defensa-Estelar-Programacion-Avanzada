## GameUI.gd
## In-game HUD: resources, lives, wave counter, tower build menu,
## tower info panel, speed/pause buttons.
extends CanvasLayer

# ─── Signals ────────────────────────────────────────────────────────────
signal wave_start_requested()
signal speed_toggled()
signal pause_toggled()
signal tower_build_requested(tower_type: int)
signal upgrade_requested()
signal sell_requested()

# ─── Node refs ──────────────────────────────────────────────────────────
@onready var resources_label: Label   = %ResourcesLabel
@onready var lives_label: Label       = %LivesLabel
@onready var wave_label: Label        = %WaveLabel
@onready var score_label: Label       = %ScoreLabel
@onready var speed_btn: Button        = %SpeedButton
@onready var pause_btn: Button        = %PauseButton
@onready var start_wave_btn: Button   = %StartWaveButton
@onready var tower_panel: Control     = %TowerPanel
@onready var info_panel: Control      = %TowerInfoPanel
@onready var tower_name_lbl: Label    = %TowerNameLabel
@onready var tower_stats_lbl: Label   = %TowerStatsLabel
@onready var upgrade_btn: Button      = %UpgradeButton
@onready var sell_btn: Button         = %SellButton
@onready var achievement_popup: Control = %AchievementPopup
@onready var achievement_label: Label   = %AchievementLabel

# ─── Lifecycle ────────────────────────────────────────────────────────────
func _ready() -> void:
	info_panel.visible = false
	achievement_popup.visible = false
	
	# Connect GameManager signals
	GameManager.resources_changed.connect(_on_resources_changed)
	GameManager.lives_changed.connect(_on_lives_changed)
	GameManager.wave_changed.connect(_on_wave_changed)
	GameManager.score_changed.connect(_on_score_changed)
	GameManager.speed_changed.connect(_on_speed_changed)
	GameManager.achievement_unlocked.connect(_on_achievement_unlocked)
	
	# Buttons
	start_wave_btn.pressed.connect(func(): wave_start_requested.emit())
	speed_btn.pressed.connect(func(): speed_toggled.emit())
	pause_btn.pressed.connect(func(): pause_toggled.emit())
	upgrade_btn.pressed.connect(func(): upgrade_requested.emit())
	sell_btn.pressed.connect(func(): sell_requested.emit())
	
	# Tower build buttons (connected by name convention in scene)
	_connect_tower_buttons()
	
	# Initial display
	_on_resources_changed(GameManager.resources)
	_on_lives_changed(GameManager.lives)
	_on_wave_changed(GameManager.current_wave)
	_on_score_changed(GameManager.score)

func _connect_tower_buttons() -> void:
	var btn_map: Dictionary = {
		"%LaserBtn":   Tower.TowerType.LASER,
		"%PlasmaBtn":  Tower.TowerType.PLASMA,
		"%CryoBtn":    Tower.TowerType.CRYO,
		"%MissileBtn": Tower.TowerType.MISSILE,
	}
	for node_path in btn_map:
		var btn: Button = get_node_or_null(node_path) as Button
		if btn:
			var t: int = btn_map[node_path]
			btn.pressed.connect(func(): tower_build_requested.emit(t))

# ─── GameManager signal handlers ────────────────────────────────────────
func _on_resources_changed(amount: int) -> void:
	resources_label.text = "⚡ %d" % amount

func _on_lives_changed(amount: int) -> void:
	lives_label.text = "❤ %d" % amount
	if amount <= 5:
		lives_label.modulate = Color(1, 0.3, 0.3)
	elif amount <= 10:
		lives_label.modulate = Color(1, 0.8, 0.2)
	else:
		lives_label.modulate = Color(1, 1, 1)

func _on_wave_changed(wave: int) -> void:
	wave_label.text = "Wave %d / %d" % [wave, GameManager.total_waves]
	start_wave_btn.disabled = (wave > 0)  # disable after first wave is manually started
	# Re-enable after each wave ends — handled below

func _on_score_changed(s: int) -> void:
	score_label.text = "Score: %d" % s

func _on_speed_changed(mult: float) -> void:
	speed_btn.text = "▶▶ x2" if mult == 1.0 else "▶ x1"

# ─── Tower info panel ────────────────────────────────────────────────────
func on_tower_selected(tower: Tower) -> void:
	info_panel.visible = true
	_refresh_tower_info(tower)

func on_tower_deselected() -> void:
	info_panel.visible = false

func _refresh_tower_info(tower: Tower) -> void:
	var info: Dictionary = tower.get_info()
	tower_name_lbl.text = "%s  Lv.%d" % [info["name"], info["level"]]
	tower_stats_lbl.text = (
		"DMG: %.1f   RNG: %.0f   ATK: %.2f/s" % [info["damage"], info["range"], info["fire_rate"]]
	)
	if info["can_upgrade"]:
		upgrade_btn.text    = "Upgrade (%d⚡)" % info["upgrade_cost"]
		upgrade_btn.disabled = false
	else:
		upgrade_btn.text    = "MAX LEVEL"
		upgrade_btn.disabled = true
	sell_btn.text = "Sell (%d⚡)" % info["sell_value"]

# ─── Wave state ──────────────────────────────────────────────────────────
func on_wave_completed() -> void:
	start_wave_btn.disabled = false
	start_wave_btn.text = "▶ Next Wave"

# ─── Achievement popup ────────────────────────────────────────────────────
func _on_achievement_unlocked(id: String) -> void:
	var data: Dictionary = GameManager.achievements.get(id, {})
	if data.is_empty(): return
	achievement_label.text = "🏆 %s\n%s" % [data["name"], data["desc"]]
	achievement_popup.visible = true
	achievement_popup.modulate.a = 1.0
	var tween := create_tween()
	tween.tween_interval(2.5)
	tween.tween_property(achievement_popup, "modulate:a", 0.0, 0.6)
	tween.tween_callback(func(): achievement_popup.visible = false)
