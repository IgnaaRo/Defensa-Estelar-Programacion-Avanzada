## MapBase.gd
## Script base compartido para todas las escenas de mapa.
## Construye visualmente el camino, decoraciones y configura el tema del mapa.
## Cada escena de mapa define su propio color y disposición del camino en _setup_map().
class_name MapBase
extends Node2D

# ─── Configuración del mapa (definida en cada escena via @export) ─────────
@export var nombre_mapa: String               = "Mapa Desconocido"
@export var color_fondo: Color                = Color(0.2, 0.15, 0.1)
@export var color_camino: Color               = Color(0.5, 0.4, 0.3)
@export var ancho_camino: float               = 44.0
@export var puntos_camino: PackedVector2Array = PackedVector2Array()

# ─── Nodos que Main.gd espera encontrar ─────────────────────────────────
# (WaveManager, TowerManager, EnemyContainer, TowerSlots, EnemyPath)
# Se agregan como hijos en el .tscn de cada mapa

@onready var fondo: ColorRect     = $Background
@onready var linea_camino: Line2D = $PathLayer/PathVisual
@onready var nucleo: Node2D       = $EnergyCore

func _ready() -> void:
	if fondo:
		fondo.color = color_fondo
	if linea_camino and puntos_camino.size() > 0:
		linea_camino.default_color = color_camino
		linea_camino.width         = ancho_camino
		linea_camino.points        = puntos_camino
	_dibujar_decoraciones()
	_animar_nucleo()

func _dibujar_decoraciones() -> void:
	pass  # Sobreescribir en subclases para decoraciones específicas del mapa

func _animar_nucleo() -> void:
	if nucleo == null: return
	var tween: Tween = create_tween().set_loops()
	tween.tween_property(nucleo, "modulate", Color(0.5, 1.0, 1.0), 1.2)
	tween.tween_property(nucleo, "modulate", Color(0.2, 0.6, 1.0), 1.2)
