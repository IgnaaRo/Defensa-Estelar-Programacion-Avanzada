## TowerSlot.gd
## Slot de colocación de torres con detección de clic.
## Usa _input() + posición del ratón para detección confiable de clics
## sin necesitar física habilitada.
class_name TowerSlot
extends Node2D

signal slot_clicked(slot: Node2D)

const RADIO_CLIC: float = 28.0

var esta_ocupado: bool = false
var _hexagono: Polygon2D
var _contorno: Line2D
var _hover: bool = false

func _ready() -> void:
	_construir_visual()
	set_process_input(true)

func _construir_visual() -> void:
	_hexagono = Polygon2D.new()
	var pts := PackedVector2Array()
	for i in 6:
		var angulo: float = deg_to_rad(60.0 * i - 30.0)
		pts.append(Vector2(cos(angulo), sin(angulo)) * 24.0)
	_hexagono.polygon = pts
	_hexagono.color   = Color(0.35, 0.35, 0.45, 0.75)
	add_child(_hexagono)

	_contorno = Line2D.new()
	var pts_contorno := PackedVector2Array(pts)
	pts_contorno.append(pts[0])
	_contorno.points        = pts_contorno
	_contorno.default_color = Color(0.5, 0.85, 1.0, 0.6)
	_contorno.width         = 1.8
	add_child(_contorno)

func _input(event: InputEvent) -> void:
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_LEFT: return
	# Convertir posición del ratón al espacio local
	var pos_local: Vector2 = to_local(get_viewport().get_mouse_position())
	if pos_local.length() <= RADIO_CLIC:
		get_viewport().set_input_as_handled()
		slot_clicked.emit(self)

func _process(_delta: float) -> void:
	# Resaltado al pasar el cursor
	var pos_local: Vector2 = to_local(get_viewport().get_mouse_position())
	var sobre: bool = pos_local.length() <= RADIO_CLIC and not esta_ocupado
	if sobre != _hover:
		_hover = sobre
		_contorno.default_color = Color(0.8, 1.0, 0.4, 0.9) if sobre else Color(0.5, 0.85, 1.0, 0.6)
		_contorno.width         = 2.5 if sobre else 1.8

func set_occupied(ocupado: bool) -> void:
	esta_ocupado = ocupado
	_hexagono.color = Color(0.25, 0.25, 0.3, 0.4) if ocupado else Color(0.35, 0.35, 0.45, 0.75)
