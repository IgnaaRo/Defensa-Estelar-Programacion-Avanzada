## UpgradeSystem.gd — Árbol tecnológico (Autoload)
extends Node

signal upgrade_purchased(id_mejora: String)
signal upgrades_changed()

# Datos de mejoras — nombres/descripciones se obtienen de Localization en tiempo de ejecución
const MEJORAS: Dictionary = {
	# ── Mejoras activas ────────────────────────────────────────────────────
	"dmg_1":       {"name_key":"upg_dmg1_name",      "desc_key":"upg_dmg1_desc",      "cost":3, "max_level":3, "icon":"⚔️"},
	"dmg_2":       {"name_key":"upg_dmg2_name",      "desc_key":"upg_dmg2_desc",      "cost":5, "max_level":1, "requires":"dmg_1", "icon":"⚔️"},
	"range_1":     {"name_key":"upg_range_name",     "desc_key":"upg_range_desc",     "cost":3, "max_level":2, "icon":"🎯"},
	"firerate_1":  {"name_key":"upg_fire_name",      "desc_key":"upg_fire_desc",      "cost":4, "max_level":2, "icon":"⚡"},
	"resources_1": {"name_key":"upg_res_name",       "desc_key":"upg_res_desc",       "cost":4, "max_level":2, "icon":"💰"},
	"lives_1":     {"name_key":"upg_lives_name",     "desc_key":"upg_lives_desc",     "cost":5, "max_level":2, "icon":"❤️"},
	# ── Próximamente ───────────────────────────────────────────────────────
	"ion_shield":  {"name_key":"upg_shield_name",    "desc_key":"upg_shield_desc",    "cost":8, "max_level":1, "icon":"🛡️", "coming_soon":true},
	"multi_shot":  {"name_key":"upg_multishot_name", "desc_key":"upg_multishot_desc", "cost":7, "max_level":1, "icon":"🔫", "coming_soon":true},
	"overcharge":  {"name_key":"upg_overcharge_name","desc_key":"upg_overcharge_desc","cost":9, "max_level":1, "icon":"🔋", "coming_soon":true},
}

var compradas: Dictionary = {}

func can_purchase(id: String) -> bool:
	if id not in MEJORAS: return false
	var d: Dictionary = MEJORAS[id]
	if d.get("coming_soon", false): return false
	if compradas.get(id, 0) >= d["max_level"]: return false
	if "requires" in d and compradas.get(d["requires"], 0) == 0: return false
	return GameManager.tech_points >= d["cost"]

func purchase(id: String) -> bool:
	if not can_purchase(id): return false
	var d: Dictionary = MEJORAS[id]
	if not GameManager.spend_tech_points(d["cost"]): return false
	compradas[id] = compradas.get(id, 0) + 1
	_aplicar(id)
	upgrade_purchased.emit(id)
	upgrades_changed.emit()
	GameManager.save_game()
	return true

func _aplicar(id: String) -> void:
	match id:
		"dmg_1","dmg_2":  GameManager.global_damage_bonus      += 0.15
		"range_1":        GameManager.global_range_bonus        += 0.10
		"firerate_1":     GameManager.global_fire_rate_bonus    += 0.12
		"resources_1":    GameManager.resources_per_kill_bonus  += 0.25
		"lives_1":        GameManager.extra_lives_bonus         += 5

func get_all_upgrades() -> Array[Dictionary]:
	var resultado: Array[Dictionary] = []
	for id in MEJORAS:
		var d: Dictionary = MEJORAS[id].duplicate()
		d["id"]            = id
		d["name"]          = Localization.t(d["name_key"] as String)
		d["desc"]          = Localization.t(d["desc_key"] as String)
		d["current_level"] = compradas.get(id, 0)
		d["can_purchase"]  = can_purchase(id)
		d["coming_soon"]   = d.get("coming_soon", false)
		resultado.append(d)
	return resultado
