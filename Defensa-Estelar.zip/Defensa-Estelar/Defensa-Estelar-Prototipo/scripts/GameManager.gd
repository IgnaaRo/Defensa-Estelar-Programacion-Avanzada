## GameManager.gd
## Singleton de autoload que gestiona el estado global del juego: recursos,
## vidas, progresión de oleadas, puntuación, logros y guardado/carga.
extends Node

# ─── Señales ────────────────────────────────────────────────────────────────
signal resources_changed(nueva_cantidad: int)
signal lives_changed(nuevas_vidas: int)
signal wave_changed(num_oleada: int)
signal game_over(victoria: bool)
signal score_changed(nueva_puntuacion: int)
signal tech_points_changed(puntos: int)
signal achievement_unlocked(id_logro: String)
signal speed_changed(multiplicador: float)

# ─── Constantes ─────────────────────────────────────────────────────────────
const RUTA_GUARDADO := "user://stellar_defense_save.tres"
const MAX_OLEADAS_NORMAL := 20
const INTERVALO_OLEADA_JEFE := 5

# ─── Modificadores de dificultad ─────────────────────────────────────────────
enum Dificultad { FACIL, NORMAL, DIFICIL }

const MODIFICADORES_DIFICULTAD := {
	Dificultad.FACIL:   { "enemy_hp": 0.7,  "enemy_speed": 0.8,  "resources": 1.5 },
	Dificultad.NORMAL:  { "enemy_hp": 1.0,  "enemy_speed": 1.0,  "resources": 1.0 },
	Dificultad.DIFICIL: { "enemy_hp": 1.5,  "enemy_speed": 1.2,  "resources": 0.75 }
}

# ─── Estado del juego ─────────────────────────────────────────────────────────
var current_difficulty: int = Dificultad.NORMAL
var current_level: int = 0
var current_wave: int = 0
var total_waves: int = MAX_OLEADAS_NORMAL
var is_infinite_mode: bool = false
var is_infinite_unlocked: bool = false

var resources: int = 150
var lives: int = 20
var max_lives: int = 20
var score: int = 0
var tech_points: int = 0

var time_scale: float = 1.0
var is_paused: bool = false
var game_running: bool = false

# ─── Bonificaciones globales de mejoras ──────────────────────────────────────
var global_damage_bonus: float = 0.0       # % acumulativo
var global_range_bonus: float = 0.0
var global_fire_rate_bonus: float = 0.0
var resources_per_kill_bonus: float = 0.0
var extra_lives_bonus: int = 0

# ─── Logros ──────────────────────────────────────────────────────────────────
var achievements: Dictionary = {
	"first_kill":     { "name_key": "ach_first_kill_name", "desc_key": "ach_first_kill_desc", "unlocked": false },
	"wave_5":         { "name_key": "ach_wave5_name",      "desc_key": "ach_wave5_desc",      "unlocked": false },
	"wave_10":        { "name_key": "ach_wave10_name",     "desc_key": "ach_wave10_desc",     "unlocked": false },
	"wave_20":        { "name_key": "ach_wave20_name",     "desc_key": "ach_wave20_desc",     "unlocked": false },
	"no_damage_wave": { "name_key": "ach_nodmg_name",      "desc_key": "ach_nodmg_desc",      "unlocked": false },
	"boss_kill":      { "name_key": "ach_boss_name",       "desc_key": "ach_boss_desc",       "unlocked": false },
	"max_tower":      { "name_key": "ach_max_name",        "desc_key": "ach_max_desc",        "unlocked": false },
	"infinite_mode":  { "name_key": "ach_inf_name",        "desc_key": "ach_inf_desc",        "unlocked": false },
}

# ─── Mejores puntuaciones por nivel ──────────────────────────────────────────
var high_scores: Dictionary = {}   # nivel_id -> puntuacion

# ─── Inicialización ──────────────────────────────────────────────────────────
func _ready() -> void:
	load_game()

func _process(_delta: float) -> void:
	Engine.time_scale = time_scale if not is_paused else 0.0

# ─── Gestión de recursos ──────────────────────────────────────────────────────
func add_resources(cantidad: int) -> void:
	var bonus := int(cantidad * (1.0 + resources_per_kill_bonus))
	resources += bonus
	resources_changed.emit(resources)

func spend_resources(cantidad: int) -> bool:
	if resources >= cantidad:
		resources -= cantidad
		resources_changed.emit(resources)
		return true
	return false

func can_afford(cantidad: int) -> bool:
	return resources >= cantidad

# ─── Gestión de vidas ────────────────────────────────────────────────────────
func lose_life(cantidad: int = 1) -> void:
	lives = max(0, lives - cantidad)
	lives_changed.emit(lives)
	if lives <= 0:
		end_game(false)

func gain_life(cantidad: int = 1) -> void:
	lives = min(max_lives, lives + cantidad)
	lives_changed.emit(lives)

# ─── Puntuación y puntos técnicos ────────────────────────────────────────────
func add_score(puntos: int) -> void:
	score += puntos
	score_changed.emit(score)

func add_tech_points(puntos: int) -> void:
	tech_points += puntos
	tech_points_changed.emit(tech_points)

func spend_tech_points(cantidad: int) -> bool:
	if tech_points >= cantidad:
		tech_points -= cantidad
		tech_points_changed.emit(tech_points)
		return true
	return false

# ─── Gestión de oleadas ──────────────────────────────────────────────────────
func advance_wave() -> void:
	current_wave += 1
	wave_changed.emit(current_wave)
	_verificar_logros_oleada()

func is_boss_wave() -> bool:
	return current_wave % INTERVALO_OLEADA_JEFE == 0

# ─── Control de velocidad ────────────────────────────────────────────────────
func toggle_speed() -> void:
	time_scale = 2.0 if time_scale == 1.0 else 1.0
	speed_changed.emit(time_scale)

func set_paused(pausado: bool) -> void:
	is_paused = pausado

# ─── Flujo del juego ─────────────────────────────────────────────────────────
func start_game(nivel: int, dificultad: int, infinito: bool = false) -> void:
	current_level      = nivel
	current_difficulty = dificultad
	is_infinite_mode   = infinito
	current_wave       = 0

	var mod: Dictionary = MODIFICADORES_DIFICULTAD[dificultad]
	resources  = int(150 * mod["resources"])
	lives      = max_lives + extra_lives_bonus
	score      = 0
	time_scale = 1.0
	is_paused  = false
	game_running = true

	resources_changed.emit(resources)
	lives_changed.emit(lives)
	wave_changed.emit(current_wave)
	score_changed.emit(score)

func end_game(victoria: bool) -> void:
	game_running = false
	time_scale   = 1.0

	if victoria:
		add_tech_points(current_wave * 2)
		_actualizar_mejor_puntuacion()
		if current_wave >= MAX_OLEADAS_NORMAL:
			unlock_achievement("wave_20")
			is_infinite_unlocked = true

	save_game()
	game_over.emit(victoria)

# ─── Logros ──────────────────────────────────────────────────────────────────
func unlock_achievement(id: String) -> void:
	if id in achievements and not achievements[id]["unlocked"]:
		achievements[id]["unlocked"] = true
		achievement_unlocked.emit(id)
		save_game()

func _verificar_logros_oleada() -> void:
	if current_wave >= 5:  unlock_achievement("wave_5")
	if current_wave >= 10: unlock_achievement("wave_10")
	if is_infinite_mode and current_wave >= 30: unlock_achievement("infinite_mode")

# ─── Helpers de dificultad ───────────────────────────────────────────────────
func get_enemy_hp_mult() -> float:
	return MODIFICADORES_DIFICULTAD[current_difficulty]["enemy_hp"]

func get_enemy_speed_mult() -> float:
	return MODIFICADORES_DIFICULTAD[current_difficulty]["enemy_speed"]

# ─── Mejores puntuaciones ────────────────────────────────────────────────────
func _actualizar_mejor_puntuacion() -> void:
	var clave := str(current_level)
	if not clave in high_scores or score > high_scores[clave]:
		high_scores[clave] = score

# ─── Guardado / Carga ────────────────────────────────────────────────────────
func save_game() -> void:
	var datos: Dictionary = {
		"achievements":            achievements,
		"high_scores":             high_scores,
		"is_infinite_unlocked":    is_infinite_unlocked,
		"tech_points":             tech_points,
		"global_damage_bonus":     global_damage_bonus,
		"global_range_bonus":      global_range_bonus,
		"global_fire_rate_bonus":  global_fire_rate_bonus,
		"resources_per_kill_bonus":resources_per_kill_bonus,
		"extra_lives_bonus":       extra_lives_bonus,
	}
	var archivo: FileAccess = FileAccess.open(RUTA_GUARDADO, FileAccess.WRITE)
	if archivo:
		archivo.store_var(datos)
		archivo.close()

func load_game() -> void:
	if not FileAccess.file_exists(RUTA_GUARDADO): return
	var archivo: FileAccess = FileAccess.open(RUTA_GUARDADO, FileAccess.READ)
	if archivo:
		var datos: Variant = archivo.get_var()
		archivo.close()
		if datos is Dictionary:
			if "achievements" in datos:
				# Merge solo el estado 'unlocked' — nunca reemplazar el dict completo
				# para preservar name_key/desc_key aunque el save sea de versión anterior
				var guardado: Dictionary = datos["achievements"]
				for id in guardado:
					if id in achievements and guardado[id] is Dictionary:
						achievements[id]["unlocked"] = guardado[id].get("unlocked", false)
			if "high_scores"              in datos: high_scores             = datos["high_scores"]
			if "is_infinite_unlocked"     in datos: is_infinite_unlocked    = datos["is_infinite_unlocked"]
			if "tech_points"              in datos: tech_points             = datos["tech_points"]
			if "global_damage_bonus"      in datos: global_damage_bonus     = datos["global_damage_bonus"]
			if "global_range_bonus"       in datos: global_range_bonus      = datos["global_range_bonus"]
			if "global_fire_rate_bonus"   in datos: global_fire_rate_bonus  = datos["global_fire_rate_bonus"]
			if "resources_per_kill_bonus" in datos: resources_per_kill_bonus= datos["resources_per_kill_bonus"]
			if "extra_lives_bonus"        in datos: extra_lives_bonus       = datos["extra_lives_bonus"]

func reset_save() -> void:
	achievements          = {}
	high_scores           = {}
	is_infinite_unlocked  = false
	tech_points           = 0
	global_damage_bonus   = 0.0
	global_range_bonus    = 0.0
	global_fire_rate_bonus= 0.0
	resources_per_kill_bonus = 0.0
	extra_lives_bonus     = 0
	save_game()
