## Localization.gd — Autoload singleton for EN/ES language support
extends Node

signal language_changed(lang: String)

var current_language: String = "es"  # default español

const STRINGS := {
	# ── Main Menu ─────────────────────────────────────────────────────────
	"game_title":        {"es": "⚡ DEFENSA ESTELAR ⚡",      "en": "⚡ STELLAR DEFENSE ⚡"},
	"game_subtitle":     {"es": "Defiende tu colonia del ataque alienígena",
	                      "en": "Defend your colony against the alien horde"},
	"select_map":        {"es": "SELECCIONAR MAPA",           "en": "SELECT MAP"},
	"difficulty":        {"es": "DIFICULTAD",                 "en": "DIFFICULTY"},
	"diff_easy":         {"es": "🟢 Fácil",                   "en": "🟢 Easy"},
	"diff_normal":       {"es": "🟡 Normal",                  "en": "🟡 Normal"},
	"diff_hard":         {"es": "🔴 Difícil",                 "en": "🔴 Hard"},
	"infinite_mode":     {"es": "♾  Modo Infinito",           "en": "♾  Infinite Mode"},
	"high_scores":       {"es": "MEJORES PUNTUACIONES",       "en": "HIGH SCORES"},
	"btn_start":         {"es": "▶  INICIAR MISIÓN",          "en": "▶  START MISSION"},
	"btn_research":      {"es": "🔬  LAB. INVESTIGACIÓN",     "en": "🔬  RESEARCH LAB"},
	"btn_achievements":  {"es": "🏆  LOGROS",                 "en": "🏆  ACHIEVEMENTS"},
	"btn_language":      {"es": "🌐  English",                "en": "🌐  Español"},

	# ── Map names ────────────────────────────────────────────────────────
	"map_1":  {"es": "1 – Desierto Alienígena",       "en": "1 – Alien Desert"},
	"map_2":  {"es": "2 – Bosque Bioluminiscente",    "en": "2 – Bioluminescent Forest"},
	"map_3":  {"es": "3 – Cañón Radioactivo",         "en": "3 – Radioactive Canyon"},
	"map_4":  {"es": "4 – Instalación Abandonada",    "en": "4 – Abandoned Facility"},
	"map_5":  {"es": "5 – Núcleo del Planeta",        "en": "5 – Planet Core"},

	# ── HUD ──────────────────────────────────────────────────────────────
	"hud_wave":          {"es": "Oleada %d / %d",            "en": "Wave %d / %d"},
	"hud_score":         {"es": "Puntos: %d",                "en": "Score: %d"},
	"btn_speed_x2":      {"es": "▶▶ x2",                     "en": "▶▶ x2"},
	"btn_speed_x1":      {"es": "▶ x1",                      "en": "▶ x1"},
	"btn_pause":         {"es": "⏸ Pausa",                   "en": "⏸ Pause"},
	"btn_send_wave":     {"es": "▶ ENVIAR OLEADA",           "en": "▶ SEND WAVE"},
	"btn_next_wave":     {"es": "▶ PRÓXIMA OLEADA",          "en": "▶ NEXT WAVE"},

	# ── Tower names & build menu ──────────────────────────────────────────
	"tower_laser":       {"es": "⚡ Láser\n80⚡",             "en": "⚡ Laser\n80⚡"},
	"tower_plasma":      {"es": "🔮 Plasma\n150⚡",           "en": "🔮 Plasma\n150⚡"},
	"tower_cryo":        {"es": "❄ Cryo\n100⚡",             "en": "❄ Cryo\n100⚡"},
	"tower_missile":     {"es": "🚀 Misil\n130⚡",            "en": "🚀 Missile\n130⚡"},

	# ── Tower info panel ─────────────────────────────────────────────────
	"tower_laser_name":   {"es": "Torre Láser",              "en": "Laser Tower"},
	"tower_plasma_name":  {"es": "Torre Plasma",             "en": "Plasma Tower"},
	"tower_cryo_name":    {"es": "Torre Cryo",               "en": "Cryo Tower"},
	"tower_missile_name": {"es": "Torre Misil",              "en": "Missile Tower"},
	"btn_upgrade":        {"es": "⬆ Mejorar (%d⚡)",         "en": "⬆ Upgrade (%d⚡)"},
	"btn_max_level":      {"es": "✓ NIVEL MÁX.",             "en": "✓ MAX LEVEL"},
	"btn_sell":           {"es": "💲 Vender (%d⚡)",          "en": "💲 Sell (%d⚡)"},
	"btn_close":          {"es": "✕ Cerrar",                 "en": "✕ Close"},
	"tower_stats":        {"es": "DMG %.1f   RNG %.0f\nATQ %.2f/s",
	                       "en": "DMG %.1f   RNG %.0f\nATK %.2f/s"},
	"tower_level":        {"es": "%s  Nv.%d",                "en": "%s  Lv.%d"},

	# ── Wave messages ────────────────────────────────────────────────────
	"wave_complete":      {"es": "✓ ¡Oleada %d completada!", "en": "✓ Wave %d Complete!"},
	"wave_incoming":      {"es": "¡Oleada %d en camino!",    "en": "Wave %d incoming!"},
	"boss_wave":          {"es": "⚠ ¡OLEADA DE JEFE %d!",   "en": "⚠ BOSS WAVE %d!"},

	# ── Research Lab ─────────────────────────────────────────────────────
	"research_title":     {"es": "🔬 LAB. DE INVESTIGACIÓN", "en": "🔬 RESEARCH LAB"},
	"tech_points":        {"es": "Puntos Tec.: %d",          "en": "Tech Points: %d"},
	"btn_buy":            {"es": "Comprar (%d PT)",          "en": "Buy (%d TP)"},
	"upgrade_level":      {"es": "Nivel %d / %d",            "en": "Level %d / %d"},

	# ── Upgrade names & descriptions ──────────────────────────────────────
	"upg_dmg1_name":      {"es": "Armamento Mejorado I",     "en": "Enhanced Weaponry I"},
	"upg_dmg1_desc":      {"es": "+15% daño global de torres","en": "+15% global tower damage"},
	"upg_dmg2_name":      {"es": "Armamento Mejorado II",    "en": "Enhanced Weaponry II"},
	"upg_dmg2_desc":      {"es": "+15% daño global (acumula)","en": "+15% global damage (stacks)"},
	"upg_range_name":     {"es": "Puntería Extendida",       "en": "Extended Targeting"},
	"upg_range_desc":     {"es": "+10% rango de torres",     "en": "+10% tower range"},
	"upg_fire_name":      {"es": "Sistemas Rápidos",         "en": "Rapid Systems"},
	"upg_fire_desc":      {"es": "+12% cadencia de disparo", "en": "+12% tower fire rate"},
	"upg_res_name":       {"es": "Drones de Salvamento",     "en": "Salvage Drones"},
	"upg_res_desc":       {"es": "+25% recursos por muerte", "en": "+25% resources per kill"},
	"upg_lives_name":     {"es": "Núcleo Reforzado",         "en": "Reinforced Core"},
	"upg_lives_desc":     {"es": "+5 vidas base",            "en": "+5 base lives"},
	"upg_cryo_name":      {"es": "Módulo Criogénico",        "en": "Cryogenics Module"},
	"upg_cryo_desc":      {"es": "Desbloquea Torre Cryo",    "en": "Unlock Cryo Tower"},
	"upg_miss_name":      {"es": "Bahía de Armamento",       "en": "Ordnance Bay"},
	"upg_miss_desc":      {"es": "Desbloquea Torre Misil",   "en": "Unlock Missile Tower"},

	# ── Achievements ─────────────────────────────────────────────────────
	"ach_title":          {"es": "🏆  LOGROS",               "en": "🏆  ACHIEVEMENTS"},
	"ach_first_kill_name":{"es": "Primera Sangre",           "en": "First Blood"},
	"ach_first_kill_desc":{"es": "Elimina tu primer alienígena","en": "Kill your first alien"},
	"ach_wave5_name":     {"es": "Sosteniendo la Línea",     "en": "Holding the Line"},
	"ach_wave5_desc":     {"es": "Sobrevive la oleada 5",    "en": "Survive wave 5"},
	"ach_wave10_name":    {"es": "Defensor Veterano",        "en": "Veteran Defender"},
	"ach_wave10_desc":    {"es": "Sobrevive la oleada 10",   "en": "Survive wave 10"},
	"ach_wave20_name":    {"es": "Colonia Salvada",          "en": "Colony Saved"},
	"ach_wave20_desc":    {"es": "Completa las 20 oleadas",  "en": "Complete all 20 waves"},
	"ach_nodmg_name":     {"es": "Impenetrable",             "en": "Impenetrable"},
	"ach_nodmg_desc":     {"es": "Completa una oleada sin perder vidas","en": "Complete a wave without losses"},
	"ach_boss_name":      {"es": "Cazador de Gigantes",      "en": "Giant Slayer"},
	"ach_boss_desc":      {"es": "Derrota a un Jefe Colosal","en": "Defeat a Colossal Boss"},
	"ach_max_name":       {"es": "Completamente Armado",     "en": "Fully Armed"},
	"ach_max_desc":       {"es": "Mejora una torre al nivel 3","en": "Upgrade a tower to level 3"},
	"ach_inf_name":       {"es": "Guerrero Infinito",        "en": "Infinite Warrior"},
	"ach_inf_desc":       {"es": "Llega a la oleada 30 en modo infinito","en": "Reach wave 30 in infinite mode"},

	# ── Árbol tecnológico — claves faltantes ────────────────────────────
	"upgrade_maxed":      {"es": "✓ AL MÁXIMO",              "en": "✓ MAXED OUT"},
	"coming_soon":        {"es": "Próximamente",              "en": "Coming Soon"},


	# ── Pantalla de resultado ─────────────────────────────────────────────
	"result_victory":     {"es": "🎉  ¡COLONIA SALVADA! 🎉", "en": "🎉  COLONY SAVED! 🎉"},
	"result_defeat":      {"es": "💀  COLONIA DESTRUIDA 💀",  "en": "💀  COLONY DESTROYED 💀"},
	"result_score":       {"es": "Puntuación Final: %d",      "en": "Final Score: %d"},
	"result_waves":       {"es": "Oleadas Sobrevividas: %d",  "en": "Waves Survived: %d"},
	"btn_retry":          {"es": "↺  Reintentar",             "en": "↺  Retry"},
	"btn_menu":           {"es": "⌂  Menú Principal",         "en": "⌂  Main Menu"},

	# ── Enemy names ──────────────────────────────────────────────────────
	"enemy_scout":        {"es": "Explorador Alien",          "en": "Alien Scout"},
	"enemy_warrior":      {"es": "Guerrero Alien",            "en": "Alien Warrior"},
	"enemy_armored":      {"es": "Alien Blindado",            "en": "Armored Alien"},
	"enemy_flyer":        {"es": "Alien Volador",             "en": "Alien Flyer"},
	"enemy_boss":         {"es": "Jefe Colosal",              "en": "Colossal Boss"},
	"enemy_boss_label":   {"es": "⚠ JEFE",                   "en": "⚠ BOSS"},
}

# ── Public API ────────────────────────────────────────────────────────────
func t(key: String) -> String:
	if key not in STRINGS:
		return key
	return STRINGS[key].get(current_language, STRINGS[key].get("en", key))

func tf(key: String, args: Array) -> String:
	return t(key) % args

func toggle_language() -> void:
	current_language = "en" if current_language == "es" else "es"
	language_changed.emit(current_language)
	_save_language()

func set_language(lang: String) -> void:
	if lang in ["es", "en"]:
		current_language = lang
		language_changed.emit(current_language)
		_save_language()

func _ready() -> void:
	_load_language()

func _save_language() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("settings", "language", current_language)
	cfg.save("user://settings.cfg")

func _load_language() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("user://settings.cfg") == OK:
		var lang: String = cfg.get_value("settings", "language", "es") as String
		current_language = lang
