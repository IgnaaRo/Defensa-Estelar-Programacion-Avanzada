## CryoTower.gd — Ralentiza enemigos, bajo daño
class_name CryoTower
extends Tower

var cantidades_slow: Array   = [0.5, 0.35, 0.2]
var duraciones_slow: Array   = [1.5, 2.0,  2.5]

func _setup_stats() -> void:
	tower_type      = TowerType.CRYO
	tower_name      = Localization.t("tower_cryo_name")
	base_damage     = 3.0
	base_range      = 130.0
	base_fire_rate  = 1.2
	base_cost       = 100
	damage_mults    = [1.0, 1.3, 1.7]
	range_mults     = [1.0, 1.2, 1.5]
	fire_rate_mults = [1.0, 1.3, 1.6]
	upgrade_costs   = [0, 80, 150]
	_color_torre    = Color(0.4, 0.9, 1.0)

func _disparar() -> void:
	if _objetivo == null: return
	var mult_slow: float = cantidades_slow[level - 1]
	var dur_slow: float  = duraciones_slow[level - 1]
	_objetivo.take_damage(damage)
	_objetivo.apply_slow(mult_slow, dur_slow)
	_rayo_cryo()

func _rayo_cryo() -> void:
	var rayo: Line2D = Line2D.new()
	rayo.default_color = Color(0.6, 0.95, 1.0, 0.8)
	rayo.width = 3.0
	rayo.add_point(Vector2.ZERO)
	rayo.add_point(to_local(_objetivo.global_position))
	add_child(rayo)
	var tw: Tween = create_tween()
	tw.tween_property(rayo, "modulate:a", 0.0, 0.15)
	tw.tween_callback(rayo.queue_free)
