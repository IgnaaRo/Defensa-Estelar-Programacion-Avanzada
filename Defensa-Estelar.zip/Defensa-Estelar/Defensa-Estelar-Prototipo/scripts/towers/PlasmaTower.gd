## PlasmaTower.gd — Lento, daño muy alto, largo alcance
class_name PlasmaTower
extends Tower

func _setup_stats() -> void:
	tower_type      = TowerType.PLASMA
	tower_name      = Localization.t("tower_plasma_name")
	base_damage     = 35.0
	base_range      = 220.0
	base_fire_rate  = 0.6
	base_cost       = 150
	damage_mults    = [1.0, 1.7, 2.8]
	range_mults     = [1.0, 1.2, 1.45]
	fire_rate_mults = [1.0, 1.25, 1.5]
	upgrade_costs   = [0, 120, 200]
	_color_torre    = Color(0.8, 0.2, 1.0)

func _disparar() -> void:
	if _objetivo == null: return
	_lanzar_bola_plasma()

func _lanzar_bola_plasma() -> void:
	var bola: Node2D = Node2D.new()
	bola.global_position = global_position
	get_parent().add_child(bola)

	var circ: ColorRect = ColorRect.new()
	circ.size = Vector2(10, 10); circ.position = Vector2(-5, -5)
	circ.color = Color(0.9, 0.3, 1.0, 0.95)
	bola.add_child(circ)

	var objetivo_ref: Node2D = _objetivo
	var dano: float = damage
	var tw: Tween = bola.create_tween()
	tw.tween_property(bola, "global_position", objetivo_ref.global_position, 0.22)
	tw.tween_callback(func():
		if is_instance_valid(bola):
			if is_instance_valid(objetivo_ref) and (objetivo_ref as Enemy).is_alive():
				(objetivo_ref as Enemy).take_damage(dano)
			_impacto_plasma(bola.global_position)
			bola.queue_free())

func _impacto_plasma(pos: Vector2) -> void:
	var flash: ColorRect = ColorRect.new()
	flash.size = Vector2(20, 20); flash.position = pos - Vector2(10, 10)
	flash.color = Color(1.0, 0.5, 1.0, 0.8)
	get_parent().add_child(flash)
	var tw: Tween = flash.create_tween()
	tw.tween_property(flash, "modulate:a", 0.0, 0.25)
	tw.tween_callback(flash.queue_free)
