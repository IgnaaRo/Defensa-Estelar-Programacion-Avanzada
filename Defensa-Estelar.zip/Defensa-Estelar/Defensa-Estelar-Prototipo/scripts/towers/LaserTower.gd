## LaserTower.gd — Disparo rápido, daño medio
class_name LaserTower
extends Tower

func _setup_stats() -> void:
	tower_type      = TowerType.LASER
	tower_name      = Localization.t("tower_laser_name")
	base_damage     = 8.0
	base_range      = 160.0
	base_fire_rate  = 2.5
	base_cost       = 80
	damage_mults    = [1.0, 1.6, 2.4]
	range_mults     = [1.0, 1.15, 1.3]
	fire_rate_mults = [1.0, 1.4, 1.8]
	upgrade_costs   = [0, 60, 120]
	_color_torre    = Color(0.2, 0.8, 1.0)

func _disparar() -> void:
	if _objetivo == null: return
	# Rayo láser instantáneo
	var rayo: Line2D = Line2D.new()
	rayo.default_color = Color(0.2, 0.9, 1.0, 0.9)
	rayo.width = 2.5
	rayo.add_point(Vector2.ZERO)
	rayo.add_point(to_local(_objetivo.global_position))
	add_child(rayo)
	_objetivo.take_damage(damage)
	# Desvanecer y eliminar
	var tw: Tween = create_tween()
	tw.tween_property(rayo, "modulate:a", 0.0, 0.08)
	tw.tween_callback(rayo.queue_free)
