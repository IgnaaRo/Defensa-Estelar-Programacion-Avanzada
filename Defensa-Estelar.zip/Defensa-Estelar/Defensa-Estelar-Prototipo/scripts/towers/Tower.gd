## Tower.gd — Clase base para todas las torres
class_name Tower
extends Node2D

signal tower_selected(torre: Tower)
signal tower_sold(torre: Tower)

enum TowerType { LASER, PLASMA, CRYO, MISSILE }

# ── Stats ──────────────────────────────────────────────────────────────────
var tower_type: TowerType   = TowerType.LASER
var tower_name: String      = "Torre"
var level: int              = 1
var max_level: int          = 3

var base_damage: float      = 10.0
var base_range: float       = 150.0
var base_fire_rate: float   = 1.0
var base_cost: int          = 100

var damage_mults:    Array  = [1.0, 1.5, 2.2]
var range_mults:     Array  = [1.0, 1.2, 1.4]
var fire_rate_mults: Array  = [1.0, 1.3, 1.6]
var upgrade_costs:   Array  = [0,   75,  150]

var sell_refund_pct: float  = 0.6

# ── Estado en tiempo real ──────────────────────────────────────────────────
var damage: float       = 10.0
var range: float        = 150.0
var fire_rate: float    = 1.0
var fire_cooldown: float = 1.0

var _timer_cooldown: float          = 0.0
var _objetivo: Node2D               = null
var _enemigos_en_rango: Array[Node2D] = []
var _total_gastado: int             = 0
var _seleccionada: bool             = false

# ── Visuales (construidos por código) ─────────────────────────────────────
var _base_hex: Polygon2D
var _canon: ColorRect
var _anillo_rango: Node2D
var _area_rango: Area2D
var _color_torre: Color = Color(0.3, 0.7, 1.0)

# ── Ciclo de vida ──────────────────────────────────────────────────────────
func _ready() -> void:
	_setup_stats()
	_recalcular_stats()
	_total_gastado = base_cost
	_construir_visuales()
	_construir_area_rango()

func _setup_stats() -> void:
	pass  # Sobreescribir en subclases

func _process(delta: float) -> void:
	if _timer_cooldown > 0.0:
		_timer_cooldown -= delta

	_limpiar_objetivos_muertos()

	if _objetivo == null or not is_instance_valid(_objetivo):
		_adquirir_objetivo()

	if _objetivo != null and _timer_cooldown <= 0.0:
		_apuntar_objetivo()
		_disparar()
		_timer_cooldown = fire_cooldown

# ── Construcción de visuales ───────────────────────────────────────────────
func _construir_visuales() -> void:
	# Base hexagonal
	_base_hex = Polygon2D.new()
	var pts := PackedVector2Array()
	for i in 6:
		var a := deg_to_rad(60.0 * i)
		pts.append(Vector2(cos(a), sin(a)) * 18.0)
	_base_hex.polygon = pts
	_base_hex.color   = _color_torre.darkened(0.4)
	add_child(_base_hex)

	# Contorno
	var contorno := Line2D.new()
	var pts_c := PackedVector2Array(pts); pts_c.append(pts[0])
	contorno.points        = pts_c
	contorno.default_color = _color_torre
	contorno.width         = 1.8
	add_child(contorno)

	# Cañón (rectángulo apuntando hacia arriba)
	_canon = ColorRect.new()
	_canon.size     = Vector2(8, 16)
	_canon.position = Vector2(-4, -16)
	_canon.color    = _color_torre
	add_child(_canon)

	# Puntos indicadores de nivel
	_dibujar_puntos_nivel()

	# Anillo de rango (oculto por defecto)
	_anillo_rango = Node2D.new()
	_anillo_rango.visible = false
	add_child(_anillo_rango)
	var linea_anillo: Line2D = Line2D.new()
	linea_anillo.name          = "RangeRing"
	linea_anillo.default_color = Color(_color_torre, 0.35)
	linea_anillo.width         = 1.5
	_construir_linea_circulo(linea_anillo, range)
	_anillo_rango.add_child(linea_anillo)

	# Área de detección de clics
	var area_clic: Area2D = Area2D.new()
	area_clic.name = "ClickDetect"
	var forma_clic: CollisionShape2D = CollisionShape2D.new()
	var circulo_clic: CircleShape2D = CircleShape2D.new(); circulo_clic.radius = 20.0
	forma_clic.shape = circulo_clic
	area_clic.add_child(forma_clic)
	area_clic.input_event.connect(func(_vp, event, _si):
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			tower_selected.emit(self))
	add_child(area_clic)

func _dibujar_puntos_nivel() -> void:
	for i in level:
		var punto := ColorRect.new()
		punto.name     = "PuntoNivel_%d" % i
		punto.size     = Vector2(4, 4)
		punto.color    = Color(1.0, 0.9, 0.3)
		punto.position = Vector2(-6 + i * 5, 12)
		add_child(punto)

func _construir_linea_circulo(linea: Line2D, radio: float) -> void:
	var pts := PackedVector2Array()
	var pasos: int = 36
	for i in pasos + 1:
		var a := TAU * i / float(pasos)
		pts.append(Vector2(cos(a), sin(a)) * radio)
	linea.points = pts

func _construir_area_rango() -> void:
	_area_rango = Area2D.new()
	_area_rango.collision_layer = 0
	_area_rango.collision_mask  = 2   # capa de enemigos
	var nodo_forma := CollisionShape2D.new()
	var circulo    := CircleShape2D.new(); circulo.radius = range
	nodo_forma.shape = circulo
	_area_rango.add_child(nodo_forma)
	_area_rango.body_entered.connect(_al_entrar_enemigo)
	_area_rango.body_exited.connect(_al_salir_enemigo)
	add_child(_area_rango)

func _actualizar_forma_rango() -> void:
	if _area_rango == null: return
	var cs: CollisionShape2D = _area_rango.get_child(0) as CollisionShape2D
	if cs and cs.shape is CircleShape2D:
		(cs.shape as CircleShape2D).radius = range
	if _anillo_rango:
		var rl: Line2D = _anillo_rango.get_node_or_null("RangeRing")
		if rl: _construir_linea_circulo(rl, range)

# ── Objetivos ──────────────────────────────────────────────────────────────
func _adquirir_objetivo() -> void:
	_objetivo = null
	var mejor: float = -1.0
	for enemigo in _enemigos_en_rango:
		if not is_instance_valid(enemigo): continue
		var prog: float = enemigo.get("path_progress") if enemigo.get("path_progress") != null else 0.0
		if prog > mejor:
			mejor     = prog
			_objetivo = enemigo

func _limpiar_objetivos_muertos() -> void:
	_enemigos_en_rango = _enemigos_en_rango.filter(
		func(e): return is_instance_valid(e) and (e as Enemy).is_alive())

func _apuntar_objetivo() -> void:
	if _objetivo == null or _canon == null: return
	var dir: Vector2 = (_objetivo.global_position - global_position).normalized()
	_canon.pivot_offset = Vector2(4, 16)
	_canon.rotation     = dir.angle() + PI / 2.0

# ── Disparo (sobreescribir por tipo de torre) ──────────────────────────────
func _disparar() -> void:
	pass

# ── Recálculo de stats ────────────────────────────────────────────────────
func _recalcular_stats() -> void:
	var idx: int = level - 1
	damage    = base_damage    * damage_mults[idx]    * (1.0 + GameManager.global_damage_bonus)
	range     = base_range     * range_mults[idx]     * (1.0 + GameManager.global_range_bonus)
	fire_rate = base_fire_rate * fire_rate_mults[idx] * (1.0 + GameManager.global_fire_rate_bonus)
	fire_cooldown = 1.0 / max(fire_rate, 0.01)
	_actualizar_forma_rango()

# ── Mejorar / Vender ──────────────────────────────────────────────────────
func can_upgrade() -> bool:
	return level < max_level and GameManager.can_afford(get_upgrade_cost())

func get_upgrade_cost() -> int:
	if level >= max_level: return 0
	return upgrade_costs[level]

func upgrade() -> bool:
	if level >= max_level: return false
	if not GameManager.spend_resources(get_upgrade_cost()): return false
	_total_gastado += upgrade_costs[level]
	level          += 1
	_recalcular_stats()
	# Refrescar puntos de nivel
	for hijo in get_children():
		if hijo.name.begins_with("PuntoNivel_"):
			hijo.queue_free()
	_dibujar_puntos_nivel()
	if level == 3:
		GameManager.unlock_achievement("max_tower")
	return true

func sell() -> void:
	GameManager.add_resources(get_sell_value())
	tower_sold.emit(self)
	queue_free()

func get_sell_value() -> int:
	return int(_total_gastado * sell_refund_pct)

func set_selected(seleccionada: bool) -> void:
	_seleccionada = seleccionada
	if _anillo_rango: _anillo_rango.visible = seleccionada

func get_info() -> Dictionary:
	return {
		"name":         tower_name,
		"level":        level,
		"damage":       snappedf(damage, 0.1),
		"range":        snappedf(range, 1.0),
		"fire_rate":    snappedf(fire_rate, 0.01),
		"upgrade_cost": get_upgrade_cost(),
		"sell_value":   get_sell_value(),
		"can_upgrade":  can_upgrade(),
	}

# ── Callbacks de rango ────────────────────────────────────────────────────
func _al_entrar_enemigo(cuerpo: Node2D) -> void:
	if cuerpo.is_in_group("enemies"):
		_enemigos_en_rango.append(cuerpo)

func _al_salir_enemigo(cuerpo: Node2D) -> void:
	_enemigos_en_rango.erase(cuerpo)
