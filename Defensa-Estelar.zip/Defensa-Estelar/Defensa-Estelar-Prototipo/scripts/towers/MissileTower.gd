## MissileTower.gd — Daño en área por explosión
class_name MissileTower
extends Tower

var radios_explosion: Array = [60.0, 80.0, 100.0]

func _setup_stats() -> void:
	tower_type      = TowerType.MISSILE
	tower_name      = Localization.t("tower_missile_name")
	base_damage     = 25.0
	base_range      = 180.0
	base_fire_rate  = 0.9
	base_cost       = 130
	damage_mults    = [1.0, 1.6, 2.5]
	range_mults     = [1.0, 1.2, 1.4]
	fire_rate_mults = [1.0, 1.2, 1.45]
	upgrade_costs   = [0, 100, 175]
	_color_torre    = Color(1.0, 0.5, 0.1)

func _disparar() -> void:
	if _objetivo == null: return
	_lanzar_misil(_objetivo)

func _lanzar_misil(objetivo: Node2D) -> void:
	var misil: Node2D = Node2D.new()
	misil.global_position = global_position
	get_parent().add_child(misil)

	var cuerpo: ColorRect = ColorRect.new()
	cuerpo.size = Vector2(6, 12); cuerpo.position = Vector2(-3, -6)
	cuerpo.color = Color(1.0, 0.6, 0.1)
	misil.add_child(cuerpo)

	var radio: float = radios_explosion[level - 1]
	var dano := damage
	var tw: Tween = misil.create_tween()
	tw.tween_property(misil, "global_position", objetivo.global_position, 0.3)
	tw.tween_callback(func():
		if is_instance_valid(misil):
			_explotar(misil.global_position, radio, dano)
			misil.queue_free())

func _explotar(pos: Vector2, radio: float, dano: float) -> void:
	# Capturar lista de enemigos primero para evitar modificar el árbol durante la iteración
	var todos: Array = get_tree().get_nodes_in_group("enemies").duplicate()
	for enemigo in todos:
		if not is_instance_valid(enemigo): continue
		if not (enemigo as Enemy).is_alive(): continue
		var dist: float = (enemigo as Node2D).global_position.distance_to(pos)
		if dist <= radio:
			var reduccion: float = 1.0 - (dist / radio) * 0.5
			(enemigo as Enemy).take_damage(dano * reduccion)

	# Anillo visual de explosión
	var anillo_nodo: Node2D = Node2D.new()
	anillo_nodo.global_position = pos
	get_parent().add_child(anillo_nodo)

	var anillo: Line2D = Line2D.new()
	anillo.default_color = Color(1.0, 0.5, 0.1, 0.85)
	anillo.width = 3.0
	_linea_circulo(anillo, 4.0)
	anillo_nodo.add_child(anillo)

	var flash: ColorRect = ColorRect.new()
	flash.size = Vector2(20, 20); flash.position = Vector2(-10, -10)
	flash.color = Color(1.0, 0.8, 0.3, 0.9)
	anillo_nodo.add_child(flash)

	var tw: Tween = anillo_nodo.create_tween()
	tw.tween_property(anillo_nodo, "scale", Vector2(radio / 4.0, radio / 4.0), 0.3)
	tw.parallel().tween_property(anillo_nodo, "modulate:a", 0.0, 0.3)
	tw.tween_callback(anillo_nodo.queue_free)

func _linea_circulo(linea: Line2D, r: float) -> void:
	var pts := PackedVector2Array()
	for i in 25: pts.append(Vector2(cos(TAU * i / 24.0), sin(TAU * i / 24.0)) * r)
	pts.append(pts[0]); linea.points = pts
