## Main.gd — Controlador de la escena raíz
## Genera mapas en tiempo de ejecución con MapBuilder,
## conecta todos los subsistemas y gestiona el flujo general del juego.
extends Node

# ─── Referencias a nodos ─────────────────────────────────────────────────
@onready var scene_container: Node2D = $SceneContainer
@onready var ui_layer: CanvasLayer   = $UILayer

var _mapa_actual: Node2D        = null
var _wave_manager: WaveManager  = null
var _tower_manager: TowerManager = null

# ─── Ciclo de vida ───────────────────────────────────────────────────────
func _ready() -> void:
	_mostrar_menu_principal()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and GameManager.game_running:
		_alternar_pausa()
	if event.is_action_pressed("speed_toggle") and GameManager.game_running:
		GameManager.toggle_speed()

# ─── Menú principal ───────────────────────────────────────────────────────
func _mostrar_menu_principal() -> void:
	_limpiar_escena()
	var menu: Control = _construir_menu_principal()
	ui_layer.add_child(menu)

func _construir_menu_principal() -> Control:
	var raiz: Control = Control.new()
	raiz.set_anchors_preset(Control.PRESET_FULL_RECT)

	var fondo: ColorRect = ColorRect.new()
	fondo.set_anchors_preset(Control.PRESET_FULL_RECT)
	fondo.color = Color(0.04, 0.04, 0.10)
	raiz.add_child(fondo)

	# Estrellas de fondo
	var rng := RandomNumberGenerator.new()
	rng.seed = 42
	for i in 80:
		var estrella := ColorRect.new()
		var tam: float = rng.randf_range(1.0, 3.0)
		estrella.size = Vector2(tam, tam)
		estrella.position = Vector2(rng.randf_range(0, 1280), rng.randf_range(0, 720))
		estrella.color = Color(1, 1, 1, rng.randf_range(0.3, 1.0))
		raiz.add_child(estrella)

	var centro: VBoxContainer = VBoxContainer.new()
	centro.set_anchors_preset(Control.PRESET_CENTER)
	centro.custom_minimum_size = Vector2(440, 620)
	centro.position = Vector2(-220, -310)
	centro.add_theme_constant_override("separation", 10)
	raiz.add_child(centro)

	var titulo: Label = Label.new()
	titulo.text = Localization.t("game_title")
	titulo.add_theme_font_size_override("font_size", 32)
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	titulo.modulate = Color(0.4, 0.9, 1.0)
	centro.add_child(titulo)

	var subtitulo: Label = Label.new()
	subtitulo.text = Localization.t("game_subtitle")
	subtitulo.add_theme_font_size_override("font_size", 13)
	subtitulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitulo.modulate = Color(0.6, 0.6, 0.8)
	centro.add_child(subtitulo)

	centro.add_child(_hacer_separador())

	var lbl_mapa: Label = Label.new()
	lbl_mapa.text = Localization.t("select_map")
	lbl_mapa.add_theme_font_size_override("font_size", 13)
	centro.add_child(lbl_mapa)

	var nombres_nivel: Array = [Localization.t("map_1"), Localization.t("map_2"),
		Localization.t("map_3"), Localization.t("map_4"), Localization.t("map_5")]
	var sel_nivel: OptionButton = OptionButton.new()
	for nombre in nombres_nivel: sel_nivel.add_item(nombre)
	centro.add_child(sel_nivel)

	var lbl_dif: Label = Label.new()
	lbl_dif.text = Localization.t("difficulty")
	lbl_dif.add_theme_font_size_override("font_size", 13)
	centro.add_child(lbl_dif)

	var sel_dif: OptionButton = OptionButton.new()
	sel_dif.add_item(Localization.t("diff_easy"))
	sel_dif.add_item(Localization.t("diff_normal"))
	sel_dif.add_item(Localization.t("diff_hard"))
	sel_dif.select(1)
	centro.add_child(sel_dif)

	var chk_infinito: CheckBox = CheckBox.new()
	chk_infinito.text    = Localization.t("infinite_mode")
	chk_infinito.visible = GameManager.is_infinite_unlocked
	centro.add_child(chk_infinito)

	centro.add_child(_hacer_separador())

	var lbl_puntos: Label = Label.new()
	lbl_puntos.text = Localization.t("high_scores")
	lbl_puntos.add_theme_font_size_override("font_size", 13)
	centro.add_child(lbl_puntos)

	for i in nombres_nivel.size():
		var s := Label.new()
		s.text = "%s  –  %d" % [nombres_nivel[i], GameManager.high_scores.get(str(i), 0)]
		s.add_theme_font_size_override("font_size", 11)
		s.modulate = Color(0.7, 0.9, 0.7)
		centro.add_child(s)

	centro.add_child(_hacer_separador())

	var btn_jugar: Button = _hacer_boton(Localization.t("btn_start"), Color(0.1, 0.55, 0.85))
	centro.add_child(btn_jugar)

	var btn_inv: Button = _hacer_boton(Localization.t("btn_research"), Color(0.45, 0.15, 0.75))
	centro.add_child(btn_inv)

	var btn_logros: Button = _hacer_boton(Localization.t("btn_achievements"), Color(0.6, 0.45, 0.05))
	centro.add_child(btn_logros)

	# Animación de pulso en el título
	var tw: Tween = raiz.create_tween().set_loops()
	tw.tween_property(titulo, "modulate", Color(0.8, 0.3, 1.0), 2.0)
	tw.tween_property(titulo, "modulate", Color(0.4, 0.9, 1.0), 2.0)

	btn_jugar.pressed.connect(func():
		_iniciar_nivel(sel_nivel.selected, sel_dif.selected, chk_infinito.button_pressed))
	btn_inv.pressed.connect(_mostrar_arbol_tech)
	btn_logros.pressed.connect(_mostrar_logros)

	# ── Botón de idioma ──
	var btn_idioma: Button = _hacer_boton(Localization.t("btn_language"), Color(0.15, 0.40, 0.55))
	centro.add_child(btn_idioma)
	btn_idioma.pressed.connect(func():
		Localization.toggle_language()
		_mostrar_menu_principal())   # reconstruir para refrescar etiquetas

	return raiz

# ─── Inicio de nivel ──────────────────────────────────────────────────────
func _iniciar_nivel(idx_nivel: int, dificultad: int, infinito: bool) -> void:
	_limpiar_escena()

	_mapa_actual = MapBuilder.build_map(idx_nivel)
	scene_container.add_child(_mapa_actual)

	_wave_manager  = _mapa_actual.get_node("WaveManager")  as WaveManager
	_tower_manager = _mapa_actual.get_node("TowerManager") as TowerManager

	var nodo_camino: Node = _mapa_actual.get_node("EnemyPath")
	_wave_manager.path_points  = nodo_camino.get_meta("waypoints", PackedVector2Array())
	_wave_manager.enemy_parent = _mapa_actual.get_node("EnemyContainer")

	var slots: Array[Node2D] = []
	for hijo in _mapa_actual.get_node("TowerSlots").get_children():
		slots.append(hijo as Node2D)
	_tower_manager.register_slots(slots)

	_wave_manager.all_waves_completed.connect(_al_completar_todas_las_oleadas)
	_wave_manager.wave_completed.connect(_al_completar_oleada)
	GameManager.game_over.connect(_al_terminar_juego, CONNECT_ONE_SHOT)

	var hud: Control = _construir_hud()
	ui_layer.add_child(hud)

	GameManager.start_game(idx_nivel, dificultad, infinito)

# ─── HUD ─────────────────────────────────────────────────────────────────
func _construir_hud() -> Control:
	var hud := Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE

	# ── Barra superior ──
	var barra_sup: PanelContainer = _hacer_panel(Color(0.04, 0.04, 0.12, 0.90))
	barra_sup.set_anchors_preset(Control.PRESET_TOP_WIDE)
	barra_sup.custom_minimum_size.y = 48
	hud.add_child(barra_sup)

	var hbox_sup: HBoxContainer = HBoxContainer.new()
	hbox_sup.set_anchors_preset(Control.PRESET_FULL_RECT)
	hbox_sup.add_theme_constant_override("separation", 18)
	barra_sup.add_child(hbox_sup)
	hbox_sup.add_child(_relleno_h(12))

	var lbl_recursos := _etiqueta_stat("⚡ 150",    Color(1.0, 0.9, 0.2), "ResourcesLabel")
	var lbl_vidas    := _etiqueta_stat("❤ 20",      Color(1.0, 0.4, 0.4), "LivesLabel")
	var lbl_oleada   := _etiqueta_stat(Localization.t("hud_wave") % [0, 20], Color(0.7, 0.9, 1.0), "WaveLabel")
	var lbl_puntos   := _etiqueta_stat(Localization.t("hud_score") % 0, Color(0.8, 0.8, 0.8), "ScoreLabel")
	hbox_sup.add_child(lbl_recursos); hbox_sup.add_child(lbl_vidas)
	hbox_sup.add_child(lbl_oleada);   hbox_sup.add_child(lbl_puntos)
	hbox_sup.add_child(_espaciador())

	var btn_vel: Button = _hacer_boton(Localization.t("btn_speed_x2"), Color(0.15, 0.55, 0.25))
	btn_vel.name = "SpeedButton"
	btn_vel.custom_minimum_size = Vector2(88, 36)
	hbox_sup.add_child(btn_vel)

	var btn_pausa: Button = _hacer_boton(Localization.t("btn_pause"), Color(0.25, 0.25, 0.55))
	btn_pausa.name = "PauseButton"
	btn_pausa.custom_minimum_size = Vector2(88, 36)
	hbox_sup.add_child(btn_pausa)

	# ── Botón volver al menú ──
	var btn_menu: Button = _hacer_boton("⌂ Menú", Color(0.5, 0.1, 0.1))
	btn_menu.custom_minimum_size = Vector2(88, 36)
	btn_menu.pressed.connect(func():
		GameManager.set_paused(false)
		Engine.time_scale = 1.0
		_mostrar_menu_principal()
	)
	hbox_sup.add_child(btn_menu)
	hbox_sup.add_child(_relleno_h(8))

	# ── Barra inferior de construcción ──
	var barra_inf: PanelContainer = _hacer_panel(Color(0.04, 0.04, 0.12, 0.90))
	barra_inf.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	barra_inf.custom_minimum_size.y = 80
	barra_inf.offset_top = -80.0
	hud.add_child(barra_inf)

	var hbox_inf: HBoxContainer = HBoxContainer.new()
	hbox_inf.set_anchors_preset(Control.PRESET_FULL_RECT)
	hbox_inf.add_theme_constant_override("separation", 8)
	barra_inf.add_child(hbox_inf)
	hbox_inf.add_child(_relleno_h(10))

	var defs_torres: Array = [
		{"etiqueta": Localization.t("tower_laser"),   "tipo": Tower.TowerType.LASER,   "color": Color(0.15, 0.6,  1.0)},
		{"etiqueta": Localization.t("tower_plasma"),  "tipo": Tower.TowerType.PLASMA,  "color": Color(0.6,  0.15, 1.0)},
		{"etiqueta": Localization.t("tower_cryo"),    "tipo": Tower.TowerType.CRYO,    "color": Color(0.2,  0.75, 0.95)},
		{"etiqueta": Localization.t("tower_missile"), "tipo": Tower.TowerType.MISSILE, "color": Color(1.0,  0.45, 0.05)},
	]
	for def in defs_torres:
		var btn: Button = _hacer_boton(def["etiqueta"] as String, def["color"] as Color)
		btn.custom_minimum_size = Vector2(100, 64)
		var t: int = def["tipo"]
		btn.pressed.connect(func(): _tower_manager.queue_build(t))
		hbox_inf.add_child(btn)

	hbox_inf.add_child(_espaciador())

	var btn_oleada: Button = _hacer_boton(Localization.t("btn_send_wave"), Color(0.65, 0.15, 0.08))
	btn_oleada.name = "StartWaveButton"
	btn_oleada.custom_minimum_size = Vector2(130, 64)
	btn_oleada.pressed.connect(func():
		if _wave_manager and not _wave_manager.is_wave_in_progress():
			_wave_manager.start_wave()
			btn_oleada.disabled = true
	)
	hbox_inf.add_child(btn_oleada)
	hbox_inf.add_child(_relleno_h(10))

	# ── Panel de info de torre (lado derecho) ──
	var panel_info: PanelContainer = _hacer_panel(Color(0.05, 0.05, 0.14, 0.94))
	panel_info.name = "TowerInfoPanel"
	panel_info.visible = false
	panel_info.set_anchor(SIDE_LEFT,  1.0); panel_info.set_anchor(SIDE_RIGHT, 1.0)
	panel_info.set_anchor(SIDE_TOP,   0.0); panel_info.set_anchor(SIDE_BOTTOM, 1.0)
	panel_info.offset_left = -215.0; panel_info.offset_right  = 0.0
	panel_info.offset_top  =  50.0;  panel_info.offset_bottom = -83.0
	hud.add_child(panel_info)

	var vbox_info: VBoxContainer = VBoxContainer.new()
	vbox_info.set_anchors_preset(Control.PRESET_FULL_RECT)
	vbox_info.add_theme_constant_override("separation", 8)
	panel_info.add_child(vbox_info)
	vbox_info.add_child(_relleno_h(0))

	var lbl_nombre_torre: Label = Label.new(); lbl_nombre_torre.name = "TowerNameLabel"
	lbl_nombre_torre.text = "—"; lbl_nombre_torre.add_theme_font_size_override("font_size", 15)
	lbl_nombre_torre.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox_info.add_child(lbl_nombre_torre)

	var lbl_stats_torre: Label = Label.new(); lbl_stats_torre.name = "TowerStatsLabel"
	lbl_stats_torre.text = ""; lbl_stats_torre.add_theme_font_size_override("font_size", 11)
	lbl_stats_torre.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_stats_torre.modulate = Color(0.75, 0.85, 0.95)
	lbl_stats_torre.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox_info.add_child(lbl_stats_torre)

	vbox_info.add_child(_hacer_separador())

	var btn_mejorar: Button = _hacer_boton("⬆ Mejorar", Color(0.15, 0.6, 0.15))
	btn_mejorar.name = "UpgradeButton"
	btn_mejorar.pressed.connect(func():
		if _tower_manager.upgrade_selected():
			_refrescar_panel_info(panel_info)
	)
	vbox_info.add_child(btn_mejorar)

	var btn_vender: Button = _hacer_boton("💲 Vender", Color(0.65, 0.35, 0.05))
	btn_vender.name = "SellButton"
	btn_vender.pressed.connect(func():
		_tower_manager.sell_selected(); panel_info.visible = false
	)
	vbox_info.add_child(btn_vender)

	var btn_cerrar: Button = _hacer_boton(Localization.t("btn_close"), Color(0.35, 0.08, 0.08))
	btn_cerrar.pressed.connect(func():
		_tower_manager.deselect_all(); panel_info.visible = false
	)
	vbox_info.add_child(btn_cerrar)

	# ── Popup de logro ──
	var popup_logro: PanelContainer = _hacer_panel(Color(0.05, 0.28, 0.08, 0.96))
	popup_logro.name = "AchievementPopup"; popup_logro.visible = false
	popup_logro.set_anchor(SIDE_LEFT, 0.5); popup_logro.set_anchor(SIDE_RIGHT, 0.5)
	popup_logro.offset_left = -145; popup_logro.offset_right  = 145
	popup_logro.offset_top  =  55;  popup_logro.offset_bottom = 118
	hud.add_child(popup_logro)

	var lbl_logro: Label = Label.new(); lbl_logro.name = "AchievementLabel"
	lbl_logro.set_anchors_preset(Control.PRESET_FULL_RECT)
	lbl_logro.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_logro.vertical_alignment   = VERTICAL_ALIGNMENT_CENTER
	popup_logro.add_child(lbl_logro)

	# ── Etiqueta de info de oleada (centro-arriba) ──
	var lbl_info_oleada: Label = Label.new(); lbl_info_oleada.name = "WaveInfoLabel"
	lbl_info_oleada.set_anchors_preset(Control.PRESET_TOP_WIDE)
	lbl_info_oleada.offset_top = 52; lbl_info_oleada.offset_bottom = 78
	lbl_info_oleada.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_info_oleada.modulate = Color(1, 0.8, 0.3, 0)
	hud.add_child(lbl_info_oleada)

	# ── Conectar señales de GameManager ──
	var _en_recursos: Callable = func(v: int):
		if not is_instance_valid(lbl_recursos): return
		lbl_recursos.text = "⚡ %d" % v
	var _en_vidas: Callable = func(v: int):
		if not is_instance_valid(lbl_vidas): return
		lbl_vidas.text = "❤ %d" % v
		lbl_vidas.modulate = Color(1, .3, .3) if v <= 5 else (Color(1, .8, .2) if v <= 10 else Color.WHITE)
	var _en_oleada: Callable = func(v: int):
		if not is_instance_valid(lbl_oleada): return
		lbl_oleada.text = Localization.t("hud_wave") % [v, GameManager.total_waves]
	var _en_puntos: Callable = func(v: int):
		if not is_instance_valid(lbl_puntos): return
		lbl_puntos.text = Localization.t("hud_score") % v
	var _en_velocidad: Callable = func(v: float):
		if not is_instance_valid(btn_vel): return
		btn_vel.text = (Localization.t("btn_speed_x1") if v > 1.0 else Localization.t("btn_speed_x2"))
	var _en_logro: Callable = func(id: String):
		if not is_instance_valid(lbl_logro): return
		var d: Dictionary = GameManager.achievements.get(id, {})
		if d.is_empty(): return
		lbl_logro.text = "🏆 %s\n%s" % [Localization.t(d["name_key"]), Localization.t(d["desc_key"])]
		popup_logro.visible = true; popup_logro.modulate.a = 1.0
		var tw2: Tween = hud.create_tween()
		tw2.tween_interval(2.5)
		tw2.tween_property(popup_logro, "modulate:a", 0.0, 0.6)
		tw2.tween_callback(func():
			if is_instance_valid(popup_logro): popup_logro.visible = false)

	GameManager.resources_changed.connect(_en_recursos)
	GameManager.lives_changed.connect(_en_vidas)
	GameManager.wave_changed.connect(_en_oleada)
	GameManager.score_changed.connect(_en_puntos)
	GameManager.speed_changed.connect(_en_velocidad)
	GameManager.achievement_unlocked.connect(_en_logro)

	# Desconectar señales al liberar el HUD
	hud.tree_exiting.connect(func():
		if GameManager.resources_changed.is_connected(_en_recursos):   GameManager.resources_changed.disconnect(_en_recursos)
		if GameManager.lives_changed.is_connected(_en_vidas):          GameManager.lives_changed.disconnect(_en_vidas)
		if GameManager.wave_changed.is_connected(_en_oleada):          GameManager.wave_changed.disconnect(_en_oleada)
		if GameManager.score_changed.is_connected(_en_puntos):         GameManager.score_changed.disconnect(_en_puntos)
		if GameManager.speed_changed.is_connected(_en_velocidad):      GameManager.speed_changed.disconnect(_en_velocidad)
		if GameManager.achievement_unlocked.is_connected(_en_logro):   GameManager.achievement_unlocked.disconnect(_en_logro))

	btn_vel.pressed.connect(GameManager.toggle_speed)
	btn_pausa.pressed.connect(_alternar_pausa)

	var _en_sel_torre: Callable = func(torre: Tower):
		if is_instance_valid(panel_info): panel_info.visible = true
		_refrescar_panel_info_torre(panel_info, torre)
	var _en_desel_torre: Callable = func():
		if is_instance_valid(panel_info): panel_info.visible = false
	var _en_oleada_done: Callable = func(_wn: int):
		if not is_instance_valid(btn_oleada): return
		btn_oleada.disabled = false
		btn_oleada.text = Localization.t("btn_next_wave")
		if is_instance_valid(lbl_info_oleada):
			_parpadear_etiqueta(lbl_info_oleada, Localization.t("wave_complete") % _wn, Color(0.3, 1.0, 0.4))
	var _en_oleada_start: Callable = func(wn: int):
		if not is_instance_valid(btn_oleada): return
		btn_oleada.disabled = true
		var es_jefe: bool = wn % 5 == 0
		if is_instance_valid(lbl_info_oleada):
			_parpadear_etiqueta(lbl_info_oleada,
				(Localization.t("boss_wave") % wn) if es_jefe else (Localization.t("wave_incoming") % wn),
				Color(1.0, 0.3, 0.3) if es_jefe else Color(1.0, 0.9, 0.3))

	_tower_manager.tower_selected.connect(_en_sel_torre)
	_tower_manager.tower_deselected.connect(_en_desel_torre)
	_wave_manager.wave_completed.connect(_en_oleada_done)
	_wave_manager.wave_started.connect(_en_oleada_start)

	# Actualizar etiquetas del HUD al cambiar idioma
	var _en_idioma: Callable = func(_lang: String):
		if not is_instance_valid(btn_oleada): return
		btn_oleada.text = Localization.t("btn_send_wave")
		if not is_instance_valid(btn_vel): return
		btn_vel.text = (Localization.t("btn_speed_x1") if GameManager.time_scale > 1.0
						else Localization.t("btn_speed_x2"))
		if not is_instance_valid(btn_pausa): return
		btn_pausa.text = Localization.t("btn_pause")
	Localization.language_changed.connect(_en_idioma)
	hud.tree_exiting.connect(func():
		if Localization.language_changed.is_connected(_en_idioma):
			Localization.language_changed.disconnect(_en_idioma))

	return hud

func _parpadear_etiqueta(lbl: Label, texto: String, color: Color) -> void:
	if not is_instance_valid(lbl): return
	lbl.text = texto; lbl.modulate = Color(color, 1.0)
	var tw: Tween = lbl.create_tween()
	tw.tween_interval(2.0)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.8)

func _refrescar_panel_info(panel: Control) -> void:
	if _tower_manager == null or _tower_manager._selected_tower == null: return
	_refrescar_panel_info_torre(panel, _tower_manager._selected_tower)

func _refrescar_panel_info_torre(panel: Control, torre: Tower) -> void:
	var info: Dictionary = torre.get_info()
	var nl: Label  = panel.find_child("TowerNameLabel",  true, false)
	var sl: Label  = panel.find_child("TowerStatsLabel", true, false)
	var ub: Button = panel.find_child("UpgradeButton",   true, false)
	var sb: Button = panel.find_child("SellButton",      true, false)
	if nl: nl.text = Localization.t("tower_level") % [info["name"], info["level"]]
	if sl: sl.text = Localization.t("tower_stats") % [info["damage"], info["range"], info["fire_rate"]]
	if ub:
		ub.text     = (Localization.t("btn_upgrade") % info["upgrade_cost"]) if info["can_upgrade"] else Localization.t("btn_max_level")
		ub.disabled = not info["can_upgrade"]
	if sb: sb.text = Localization.t("btn_sell") % info["sell_value"]

# ─── Árbol tecnológico ────────────────────────────────────────────────────
func _mostrar_arbol_tech() -> void:
	ui_layer.add_child(_construir_overlay_tech())

func _construir_overlay_tech() -> Control:
	var overlay: ColorRect = ColorRect.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.color = Color(0, 0, 0, 0.75)

	var panel: PanelContainer = _hacer_panel(Color(0.05, 0.05, 0.15, 0.97))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(740, 560)
	panel.offset_left = -370; panel.offset_right  = 370
	panel.offset_top  = -280; panel.offset_bottom = 280
	overlay.add_child(panel)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 10)
	panel.add_child(vbox)

	var cabecera: HBoxContainer = HBoxContainer.new(); vbox.add_child(cabecera)
	var lbl_titulo: Label = Label.new(); lbl_titulo.text = Localization.t("research_title")
	lbl_titulo.add_theme_font_size_override("font_size", 22)
	lbl_titulo.modulate = Color(0.5, 0.8, 1.0); cabecera.add_child(lbl_titulo)
	cabecera.add_child(_espaciador())
	var lbl_pt: Label = Label.new()
	lbl_pt.text = Localization.t("tech_points") % GameManager.tech_points
	lbl_pt.add_theme_font_size_override("font_size", 16)
	lbl_pt.modulate = Color(1.0, 0.9, 0.3); cabecera.add_child(lbl_pt)

	var _en_pt: Callable = func(v: int):
		if is_instance_valid(lbl_pt): lbl_pt.text = Localization.t("tech_points") % v
	GameManager.tech_points_changed.connect(_en_pt)
	overlay.tree_exiting.connect(func():
		if GameManager.tech_points_changed.is_connected(_en_pt):
			GameManager.tech_points_changed.disconnect(_en_pt))

	vbox.add_child(_hacer_separador())

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(scroll)

	var grilla: GridContainer = GridContainer.new()
	grilla.columns = 2
	grilla.add_theme_constant_override("h_separation", 10)
	grilla.add_theme_constant_override("v_separation", 10)
	scroll.add_child(grilla)

	_poblar_grilla_mejoras(grilla)

	# Refrescar grilla al comprar una mejora
	var _en_mejora: Callable = func():
		if not is_instance_valid(grilla): return
		for hijo in grilla.get_children(): hijo.queue_free()
		_poblar_grilla_mejoras(grilla)
	UpgradeSystem.upgrades_changed.connect(_en_mejora)
	overlay.tree_exiting.connect(func():
		if UpgradeSystem.upgrades_changed.is_connected(_en_mejora):
			UpgradeSystem.upgrades_changed.disconnect(_en_mejora))

	vbox.add_child(_hacer_separador())
	var btn_cerrar: Button = _hacer_boton(Localization.t("btn_close"), Color(0.45, 0.08, 0.08))
	btn_cerrar.pressed.connect(overlay.queue_free); vbox.add_child(btn_cerrar)

	return overlay

## Poblar el GridContainer con tarjetas de mejora
func _poblar_grilla_mejoras(grilla: GridContainer) -> void:
	for mejora in UpgradeSystem.get_all_upgrades():
		var tarjeta: PanelContainer = _hacer_tarjeta_mejora(mejora)
		grilla.add_child(tarjeta)

func _hacer_tarjeta_mejora(datos: Dictionary) -> Control:
	var es_pronto: bool = datos.get("coming_soon", false)
	var nivel_actual: int = datos.get("current_level", 0)
	var nivel_max: int   = datos.get("max_level", 1)
	var al_max: bool     = nivel_actual >= nivel_max
	var puede: bool      = datos.get("can_purchase", false) as bool

	var color_fondo: Color = (
		Color(0.07, 0.18, 0.07) if (puede and not al_max and not es_pronto) else
		Color(0.18, 0.12, 0.04) if al_max else
		Color(0.06, 0.06, 0.14)
	)
	var p: PanelContainer = _hacer_panel(color_fondo)
	p.custom_minimum_size = Vector2(310, 100)

	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	h.set_anchors_preset(Control.PRESET_FULL_RECT)
	p.add_child(h)

	# Columna de ícono
	var lbl_icono: Label = Label.new()
	lbl_icono.text = "🔒" if es_pronto else ("✅" if al_max else datos.get("icon", ""))
	lbl_icono.add_theme_font_size_override("font_size", 26)
	lbl_icono.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl_icono.custom_minimum_size = Vector2(36, 0)
	h.add_child(lbl_icono)

	# Columna de texto
	var v: VBoxContainer = VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(v)

	var lbl_nombre: Label = Label.new()
	lbl_nombre.text = datos.get("name", "")
	lbl_nombre.add_theme_font_size_override("font_size", 13)
	lbl_nombre.modulate = Color(0.6, 0.6, 0.6) if es_pronto else Color(1.0, 1.0, 1.0)
	v.add_child(lbl_nombre)

	var lbl_desc: Label = Label.new()
	lbl_desc.text = ("🚧 " + Localization.t("coming_soon")) if es_pronto else datos.get("desc", "")
	lbl_desc.add_theme_font_size_override("font_size", 11)
	lbl_desc.modulate = Color(0.55, 0.55, 0.55) if es_pronto else Color(0.75, 0.85, 0.75)
	lbl_desc.autowrap_mode = TextServer.AUTOWRAP_WORD
	v.add_child(lbl_desc)

	# Puntos de nivel
	var pips: HBoxContainer = HBoxContainer.new()
	pips.add_theme_constant_override("separation", 4)
	v.add_child(pips)
	for i in nivel_max:
		var punto: ColorRect = ColorRect.new()
		punto.custom_minimum_size = Vector2(10, 10)
		punto.color = Color(0.3, 0.9, 0.4) if i < nivel_actual else Color(0.25, 0.25, 0.25)
		pips.add_child(punto)

	# Botón de compra
	var texto_btn: String = (
		Localization.t("upgrade_maxed") if al_max else
		("🚧 " + Localization.t("coming_soon") if es_pronto else
		Localization.t("btn_buy") % (datos.get("cost", 0) as int))
	)
	var color_btn: Color = (
		Color(0.3, 0.55, 0.3) if al_max else Color(0.25, 0.25, 0.25)
	) if (al_max or es_pronto or not puede) else Color(0.15, 0.55, 0.15)

	var btn: Button = _hacer_boton(texto_btn, color_btn)
	btn.disabled = (not puede) or al_max or es_pronto
	if not btn.disabled:
		var uid: String = datos.get("id", "")
		btn.pressed.connect(func(): UpgradeSystem.purchase(uid))
	h.add_child(btn)

	return p

# ─── Pantalla de logros ───────────────────────────────────────────────────
func _mostrar_logros() -> void:
	var overlay: ColorRect = ColorRect.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.color = Color(0, 0, 0, 0.78)
	ui_layer.add_child(overlay)

	var panel: PanelContainer = _hacer_panel(Color(0.05, 0.05, 0.15, 0.97))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(560, 480)
	panel.offset_left = -280; panel.offset_right  = 280
	panel.offset_top  = -240; panel.offset_bottom = 240
	overlay.add_child(panel)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 8); panel.add_child(vbox)

	var lbl_titulo: Label = Label.new(); lbl_titulo.text = Localization.t("ach_title")
	lbl_titulo.add_theme_font_size_override("font_size", 22)
	lbl_titulo.modulate = Color(1.0, 0.85, 0.2)
	lbl_titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vbox.add_child(lbl_titulo)
	vbox.add_child(_hacer_separador())

	for id in GameManager.achievements:
		var d: Dictionary = GameManager.achievements[id]
		var fila := HBoxContainer.new()
		fila.add_theme_constant_override("separation", 10)
		var icono := Label.new()
		icono.text = "🏆" if d["unlocked"] else "🔒"
		icono.add_theme_font_size_override("font_size", 20); fila.add_child(icono)
		var col_v := VBoxContainer.new()
		var lbl_n: Label = Label.new(); lbl_n.text = Localization.t(d.get("name_key", ""))
		lbl_n.add_theme_font_size_override("font_size", 14)
		lbl_n.modulate = Color(1.0, 0.9, 0.4) if d["unlocked"] else Color(0.5, 0.5, 0.5)
		col_v.add_child(lbl_n)
		var lbl_d: Label = Label.new(); lbl_d.text = Localization.t(d.get("desc_key", ""))
		lbl_d.add_theme_font_size_override("font_size", 11)
		lbl_d.modulate = Color(0.7, 0.7, 0.7); col_v.add_child(lbl_d)
		fila.add_child(col_v); vbox.add_child(fila)

	vbox.add_child(_espaciador())
	var btn_cerrar: Button = _hacer_boton(Localization.t("btn_close"), Color(0.45, 0.08, 0.08))
	btn_cerrar.pressed.connect(overlay.queue_free); vbox.add_child(btn_cerrar)

# ─── Manejadores de eventos del juego ────────────────────────────────────
func _al_completar_todas_las_oleadas() -> void:
	GameManager.end_game(true)

func _al_completar_oleada(wn: int) -> void:
	# Después de oleadas de jefe, mostrar árbol tech
	if wn % 5 == 0 and wn < GameManager.total_waves:
		await get_tree().create_timer(1.0).timeout
		GameManager.set_paused(true)
		var tech: Control = _construir_overlay_tech()
		ui_layer.add_child(tech)
		tech.tree_exited.connect(func(): GameManager.set_paused(false))

func _al_terminar_juego(victoria: bool) -> void:
	await get_tree().create_timer(1.5).timeout
	_mostrar_resultado(victoria)

func _mostrar_resultado(victoria: bool) -> void:
	var overlay: ColorRect = ColorRect.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.color = Color(0, 0, 0, 0.78); ui_layer.add_child(overlay)

	var panel: PanelContainer = _hacer_panel(Color(0.05, 0.05, 0.15, 0.97))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(440, 300)
	panel.offset_left = -220; panel.offset_right  = 220
	panel.offset_top  = -150; panel.offset_bottom = 150
	overlay.add_child(panel)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 16); panel.add_child(vbox)

	var lbl_titulo: Label = Label.new()
	lbl_titulo.text = (Localization.t("result_victory") if victoria else Localization.t("result_defeat"))
	lbl_titulo.modulate = Color(0.3, 1.0, 0.4) if victoria else Color(1.0, 0.3, 0.3)
	lbl_titulo.add_theme_font_size_override("font_size", 26)
	lbl_titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vbox.add_child(lbl_titulo)

	var lbl_puntaje: Label = Label.new(); lbl_puntaje.text = Localization.t("result_score") % GameManager.score
	lbl_puntaje.add_theme_font_size_override("font_size", 18)
	lbl_puntaje.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vbox.add_child(lbl_puntaje)

	var lbl_oleadas: Label = Label.new(); lbl_oleadas.text = Localization.t("result_waves") % GameManager.current_wave
	lbl_oleadas.add_theme_font_size_override("font_size", 16)
	lbl_oleadas.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vbox.add_child(lbl_oleadas)

	var hbox: HBoxContainer = HBoxContainer.new()
	hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	hbox.add_theme_constant_override("separation", 20); vbox.add_child(hbox)

	var btn_reintentar: Button = _hacer_boton(Localization.t("btn_retry"), Color(0.25, 0.45, 0.75))
	btn_reintentar.pressed.connect(func():
		overlay.queue_free()
		_iniciar_nivel(GameManager.current_level, GameManager.current_difficulty, GameManager.is_infinite_mode))
	hbox.add_child(btn_reintentar)

	var btn_menu: Button = _hacer_boton(Localization.t("btn_menu"), Color(0.45, 0.15, 0.65))
	btn_menu.pressed.connect(func(): overlay.queue_free(); _mostrar_menu_principal())
	hbox.add_child(btn_menu)

# ─── Helpers ──────────────────────────────────────────────────────────────
func _limpiar_escena() -> void:
	for c in scene_container.get_children(): c.queue_free()
	for c in ui_layer.get_children():        c.queue_free()
	_mapa_actual = null; _wave_manager = null; _tower_manager = null
	GameManager.set_paused(false); Engine.time_scale = 1.0

func _alternar_pausa() -> void:
	GameManager.set_paused(not GameManager.is_paused)

static func _hacer_boton(texto: String, color: Color) -> Button:
	var btn := Button.new(); btn.text = texto
	btn.add_theme_color_override("font_color", Color.WHITE)
	for estado in ["normal", "hover", "pressed", "disabled"]:
		var c: Color = (color.lightened(0.15) if estado == "hover" else
				 (color.darkened(0.2)   if estado == "pressed" else
				 (Color(0.25, 0.25, 0.25) if estado == "disabled" else color)))
		btn.add_theme_stylebox_override(estado, _sb(c))
	return btn

static func _sb(color: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new(); s.bg_color = color
	for esquina in ["top_left", "top_right", "bottom_left", "bottom_right"]:
		s.set("corner_radius_" + esquina, 5)
	s.content_margin_top = 6; s.content_margin_bottom = 6
	s.content_margin_left = 10; s.content_margin_right = 10; return s

static func _hacer_panel(color: Color) -> PanelContainer:
	var p := PanelContainer.new(); var s := StyleBoxFlat.new(); s.bg_color = color
	for esquina in ["top_left", "top_right", "bottom_left", "bottom_right"]:
		s.set("corner_radius_" + esquina, 8)
	s.border_color = Color(0.3, 0.4, 0.6, 0.4)
	for lado in ["left", "right", "top", "bottom"]: s.set("border_width_" + lado, 1)
	p.add_theme_stylebox_override("panel", s); return p

static func _etiqueta_stat(texto: String, color: Color, nombre: String = "") -> Label:
	var l := Label.new(); l.text = texto; if nombre != "": l.name = nombre
	l.add_theme_font_size_override("font_size", 16)
	l.modulate = color; l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; return l

static func _espaciador() -> Control:
	var s := Control.new(); s.size_flags_horizontal = Control.SIZE_EXPAND_FILL; return s

static func _relleno_h(w: int) -> Control:
	var p := Control.new(); p.custom_minimum_size.x = float(w); return p

static func _hacer_separador() -> HSeparator:
	var s := HSeparator.new(); s.modulate = Color(0.3, 0.3, 0.5, 0.5); return s
