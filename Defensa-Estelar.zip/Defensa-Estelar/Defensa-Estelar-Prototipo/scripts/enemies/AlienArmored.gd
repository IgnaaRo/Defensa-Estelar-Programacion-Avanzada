class_name AlienArmored
extends Enemy
func _setup_stats() -> void:
	enemy_type=TipoEnemigo.BLINDADO; enemy_name=Localization.t("enemy_armored")
	max_hp=350.0; base_speed=40.0; reward=30; score_value=150
	armor=0.35; is_flying=false; body_color=Color(0.5,0.5,0.7)
