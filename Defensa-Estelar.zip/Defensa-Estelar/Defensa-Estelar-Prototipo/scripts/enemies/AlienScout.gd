class_name AlienScout
extends Enemy
func _setup_stats() -> void:
	enemy_type=TipoEnemigo.EXPLORADOR; enemy_name=Localization.t("enemy_scout")
	max_hp=40.0; base_speed=120.0; reward=8; score_value=40
	armor=0.0; is_flying=false; body_color=Color(0.4,0.9,0.3)
