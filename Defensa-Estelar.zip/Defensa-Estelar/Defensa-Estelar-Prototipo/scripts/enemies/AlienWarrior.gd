class_name AlienWarrior
extends Enemy
func _setup_stats() -> void:
	enemy_type=TipoEnemigo.GUERRERO; enemy_name=Localization.t("enemy_warrior")
	max_hp=120.0; base_speed=70.0; reward=15; score_value=75
	armor=0.1; is_flying=false; body_color=Color(0.9,0.5,0.1)
