## ColossalBoss.gd — Regenera vida y spawnea secuaces
class_name ColossalBoss
extends Enemy

const RUTA_SECUAZ := "res://scenes/enemies/AlienScout.tscn"

var tasa_regen: float      = 5.0
var cooldown_spawn: float  = 8.0
var _timer_spawn: float    = 0.0
var _camino_secuaces: PackedVector2Array = []

func _setup_stats() -> void:
	enemy_type  = TipoEnemigo.JEFE
	enemy_name  = Localization.t("enemy_boss")
	max_hp      = 2000.0; base_speed = 30.0; reward = 200; score_value = 1000
	armor       = 0.25; is_flying = false; body_color = Color(1.0, 0.2, 0.2)

func init_path(puntos: PackedVector2Array) -> void:
	super.init_path(puntos); _camino_secuaces = puntos

func _construir_visuales() -> void:
	super._construir_visuales()
	# Hacer al jefe visiblemente más grande
	scale = Vector2(2.2, 2.2)
	# Etiqueta de advertencia
	var etiqueta: Label = Label.new()
	etiqueta.text = Localization.t("enemy_boss_label"); etiqueta.position = Vector2(-16, -36)
	etiqueta.add_theme_font_size_override("font_size", 10)
	etiqueta.modulate = Color(1, 0.3, 0.3); add_child(etiqueta)

func _physics_process(delta: float) -> void:
	super._physics_process(delta)
	if not _alive: return
	hp = min(max_hp, hp + tasa_regen * delta)
	_actualizar_barra_vida()
	_timer_spawn -= delta
	if _timer_spawn <= 0.0:
		_spawnear_secuaces(); _timer_spawn = cooldown_spawn

func _spawnear_secuaces() -> void:
	var contenedor: Node = get_parent()
	if contenedor == null: return
	var escena: PackedScene = load(RUTA_SECUAZ) as PackedScene
	if escena == null: return
	for i in 2:
		var secuaz: Enemy = escena.instantiate() as Enemy
		contenedor.add_child(secuaz)
		secuaz.init_path(_camino_secuaces)
		secuaz.global_position = global_position + Vector2(randf_range(-24, 24), randf_range(-24, 24))
