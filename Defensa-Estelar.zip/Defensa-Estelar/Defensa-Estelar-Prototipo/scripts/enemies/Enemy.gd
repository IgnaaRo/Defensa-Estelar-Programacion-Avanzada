## Enemy.gd — Clase base de enemigos con seguimiento de camino y efectos de estado
class_name Enemy
extends CharacterBody2D

signal enemy_died(enemigo: Enemy, recompensa: int)
signal enemy_reached_end(enemigo: Enemy)

enum TipoEnemigo { EXPLORADOR, GUERRERO, BLINDADO, VOLADOR, JEFE }

# ── Stats base ─────────────────────────────────────────────────────────────
var enemy_type: TipoEnemigo = TipoEnemigo.EXPLORADOR
var enemy_name: String      = "Explorador Alien"
var max_hp: float           = 50.0
var base_speed: float       = 90.0
var reward: int             = 10
var score_value: int        = 50
var armor: float            = 0.0
var is_flying: bool         = false
var body_color: Color       = Color(0.6, 0.9, 0.3)

# ── Estado en tiempo real ──────────────────────────────────────────────────
var hp: float             = 50.0
var current_speed: float  = 90.0
var path_progress: float  = 0.0
var _alive: bool          = true

# ── Efectos de estado ──────────────────────────────────────────────────────
var _slow_timer: float    = 0.0
var _slow_mult: float     = 1.0

# ── Datos del camino ────────────────────────────────────────────────────────
var _path_points: PackedVector2Array = []
var _longitud_total: float           = 0.0
var _segmento_actual: int            = 0
var _distancia_recorrida: float      = 0.0

# ── Nodos visuales (construidos por código) ────────────────────────────────
var _cuerpo: Node2D
var _hp_fondo: ColorRect
var _hp_barra: ColorRect
var _overlay_slow: ColorRect

# ── Ciclo de vida ──────────────────────────────────────────────────────────
func _ready() -> void:
	_setup_stats()
	_aplicar_dificultad()
	hp            = max_hp
	current_speed = base_speed
	add_to_group("enemies")
	if is_flying: add_to_group("flying_enemies")
	collision_layer = 2
	collision_mask  = 0
	_construir_visuales()

func _setup_stats() -> void:
	pass  # Sobreescribir en subclases

func _aplicar_dificultad() -> void:
	max_hp     *= GameManager.get_enemy_hp_mult()
	base_speed *= GameManager.get_enemy_speed_mult()

func _construir_visuales() -> void:
	_cuerpo = Node2D.new()
	add_child(_cuerpo)

	# Forma del cuerpo
	var poly: Polygon2D = Polygon2D.new()
	var pts  := PackedVector2Array()
	var lados: int = 6 if not is_flying else 3
	for i in lados:
		var a := TAU * i / float(lados)
		pts.append(Vector2(cos(a), sin(a)) * 12.0)
	poly.polygon = pts
	poly.color   = body_color
	_cuerpo.add_child(poly)

	# Contorno
	var contorno: Line2D = Line2D.new()
	var pts_c: PackedVector2Array = PackedVector2Array(pts); pts_c.append(pts[0])
	contorno.points        = pts_c
	contorno.default_color = body_color.lightened(0.3)
	contorno.width         = 1.5
	_cuerpo.add_child(contorno)

	# Fondo de barra de vida
	_hp_fondo = ColorRect.new()
	_hp_fondo.size = Vector2(24, 4); _hp_fondo.position = Vector2(-12, -18)
	_hp_fondo.color = Color(0.2, 0.2, 0.2, 0.8)
	add_child(_hp_fondo)

	# Relleno de barra de vida
	_hp_barra = ColorRect.new()
	_hp_barra.size = Vector2(24, 4); _hp_barra.position = Vector2(-12, -18)
	_hp_barra.color = Color(0.2, 0.9, 0.3)
	add_child(_hp_barra)

	# Overlay de ralentización
	_overlay_slow = ColorRect.new()
	_overlay_slow.size = Vector2(24, 24); _overlay_slow.position = Vector2(-12, -12)
	_overlay_slow.color = Color(0.4, 0.8, 1.0, 0.0)
	add_child(_overlay_slow)

	_actualizar_barra_vida()

func _actualizar_barra_vida() -> void:
	if _hp_barra == null: return
	var pct: float = hp / max_hp
	_hp_barra.size.x = 24.0 * pct
	_hp_barra.color = Color(0.9, 0.1, 0.1) if pct < 0.3 else (Color(0.9, 0.7, 0.1) if pct < 0.6 else Color(0.2, 0.9, 0.3))

# ── Inicialización del camino ───────────────────────────────────────────────
func init_path(puntos: PackedVector2Array) -> void:
	_path_points   = puntos
	_longitud_total = _calcular_longitud(puntos)
	if puntos.size() > 0:
		global_position = puntos[0]

func _calcular_longitud(pts: PackedVector2Array) -> float:
	var total := 0.0
	for i in range(1, pts.size()):
		total += pts[i-1].distance_to(pts[i])
	return total

# ── Física ─────────────────────────────────────────────────────────────────
func _physics_process(delta: float) -> void:
	if not _alive: return
	_procesar_estados(delta)
	_mover(delta)

func _mover(delta: float) -> void:
	if _path_points.size() < 2 or _segmento_actual >= _path_points.size() - 1:
		_al_llegar_al_final(); return

	var velocidad: float = current_speed * _slow_mult
	var paso := velocidad * delta
	var destino: Vector2 = _path_points[_segmento_actual + 1]
	var dist := global_position.distance_to(destino)

	if paso >= dist:
		global_position       = destino
		_segmento_actual     += 1
		_distancia_recorrida += dist
		if _segmento_actual >= _path_points.size() - 1:
			_al_llegar_al_final(); return
	else:
		var dir: Vector2 = (destino - global_position).normalized()
		global_position      += dir * paso
		_distancia_recorrida += paso
		if _cuerpo: _cuerpo.rotation = dir.angle() + PI / 2.0

	if _longitud_total > 0.0:
		path_progress = _distancia_recorrida / _longitud_total

# ── Daño y estados ─────────────────────────────────────────────────────────
func take_damage(cantidad: float) -> void:
	if not _alive: return
	var dano_real: float = cantidad * (1.0 - armor)
	hp -= dano_real
	_actualizar_barra_vida()
	_mostrar_numero_dano(dano_real)
	if hp <= 0.0: _morir()

func apply_slow(mult: float, duracion: float) -> void:
	_slow_mult  = min(_slow_mult, mult)
	_slow_timer = max(_slow_timer, duracion)
	if _overlay_slow: _overlay_slow.color.a = 0.45

func _procesar_estados(delta: float) -> void:
	if _slow_timer > 0.0:
		_slow_timer -= delta
		if _slow_timer <= 0.0:
			_slow_mult = 1.0
			if _overlay_slow: _overlay_slow.color.a = 0.0

# ── Eventos ────────────────────────────────────────────────────────────────
func _morir() -> void:
	if not _alive: return
	_alive = false
	GameManager.add_resources(reward)
	GameManager.add_score(score_value)
	GameManager.unlock_achievement("first_kill")
	if enemy_type == TipoEnemigo.JEFE:
		GameManager.unlock_achievement("boss_kill")
	enemy_died.emit(self, reward)
	# Flash de muerte
	set_physics_process(false)
	set_process(false)
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate", Color(2.0, 2.0, 2.0, 0.0), 0.22)
	tw.tween_callback(queue_free)

func _al_llegar_al_final() -> void:
	if not _alive: return
	_alive = false
	GameManager.lose_life(1 if enemy_type != TipoEnemigo.JEFE else 5)
	enemy_reached_end.emit(self)
	queue_free()

func is_alive() -> bool:
	return _alive and hp > 0.0

func _mostrar_numero_dano(cantidad: float) -> void:
	# Agregar etiqueta al contenedor padre para que sobreviva después de que el enemigo sea liberado
	var contenedor: Node = get_parent()
	if contenedor == null: return
	var lbl: Label = Label.new()
	lbl.text = "-%d" % int(cantidad)
	lbl.add_theme_font_size_override("font_size", 11)
	lbl.modulate = Color(1, 0.3, 0.3)
	lbl.position = global_position + Vector2(-8, -28)
	contenedor.add_child(lbl)
	var tw: Tween = lbl.create_tween()
	tw.tween_property(lbl, "position", lbl.position + Vector2(0, -22), 0.45)
	tw.parallel().tween_property(lbl, "modulate:a", 0.0, 0.45)
	tw.tween_callback(lbl.queue_free)
