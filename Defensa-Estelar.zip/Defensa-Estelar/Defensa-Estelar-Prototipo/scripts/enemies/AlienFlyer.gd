## AlienFlyer.gd — Vuela directo al final, ignora las curvas del camino
class_name AlienFlyer
extends Enemy

func _setup_stats() -> void:
	enemy_type  = TipoEnemigo.VOLADOR
	enemy_name  = Localization.t("enemy_flyer")
	max_hp      = 80.0; base_speed = 100.0; reward = 20; score_value = 100
	armor       = 0.0; is_flying = true; body_color = Color(0.7, 0.3, 1.0)

func _mover(delta: float) -> void:
	if _path_points.size() == 0: return
	var destino: Vector2 = _path_points[-1]
	var velocidad := current_speed * _slow_mult
	var dist      := global_position.distance_to(destino)
	if dist <= velocidad * delta:
		global_position = destino; _al_llegar_al_final()
	else:
		var dir: Vector2 = (destino - global_position).normalized()
		global_position += dir * velocidad * delta
		if _cuerpo: _cuerpo.rotation = dir.angle() + PI / 2.0
		path_progress = 1.0 - (dist / max(_longitud_total, 1.0))
