## MapBuilder.gd
## Helper estático que crea nodos de mapa completos en tiempo de ejecución.
## Llamado desde Main.gd en lugar de cargar .tscn.
## Evita editar manualmente archivos .tscn que son frágiles.
extends Node

# ─── Definiciones de mapas ────────────────────────────────────────────────
const DATOS_MAPAS := [
	{
		"nombre":      "Desierto Alienígena",
		"fondo":       Color(0.55, 0.38, 0.18),
		"color_camino":Color(0.7,  0.55, 0.30),
		"puntos": [
			Vector2(-50, 360), Vector2(200, 360), Vector2(200, 150),
			Vector2(500, 150), Vector2(500, 500), Vector2(800, 500),
			Vector2(800, 250), Vector2(1100, 250), Vector2(1330, 250)
		],
		"slots": [
			Vector2(120, 270), Vector2(310, 150), Vector2(350, 380),
			Vector2(500, 330), Vector2(650, 500), Vector2(800, 370),
			Vector2(950, 250), Vector2(1100, 150), Vector2(1100, 370),
		]
	},
	{
		"nombre":      "Bosque Bioluminiscente",
		"fondo":       Color(0.05, 0.12, 0.08),
		"color_camino":Color(0.15, 0.55, 0.30),
		"puntos": [
			Vector2(-50, 200), Vector2(300, 200), Vector2(300, 520),
			Vector2(640, 520), Vector2(640, 200), Vector2(980, 200),
			Vector2(980, 520), Vector2(1330, 520)
		],
		"slots": [
			Vector2(150, 330), Vector2(150, 100), Vector2(465, 200),
			Vector2(465, 520), Vector2(640, 360), Vector2(810, 200),
			Vector2(810, 520), Vector2(1150, 360), Vector2(1150, 100),
		]
	},
	{
		"nombre":      "Cañón Radioactivo",
		"fondo":       Color(0.12, 0.18, 0.08),
		"color_camino":Color(0.45, 0.62, 0.15),
		"puntos": [
			Vector2(-50, 100), Vector2(400, 100), Vector2(640, 360),
			Vector2(900, 620), Vector2(1330, 620)
		],
		"slots": [
			Vector2(200, 200), Vector2(400, 250), Vector2(550, 150),
			Vector2(640, 500), Vector2(750, 250), Vector2(900, 470),
			Vector2(1050, 500), Vector2(1200, 480), Vector2(1100, 280),
		]
	},
	{
		"nombre":      "Instalación Abandonada",
		"fondo":       Color(0.18, 0.18, 0.22),
		"color_camino":Color(0.55, 0.55, 0.65),
		"puntos": [
			Vector2(-50, 360), Vector2(250, 360), Vector2(250, 120),
			Vector2(640, 120), Vector2(640, 600), Vector2(1030, 600),
			Vector2(1030, 360), Vector2(1330, 360)
		],
		"slots": [
			Vector2(120, 240), Vector2(380, 120), Vector2(380, 480),
			Vector2(640, 360), Vector2(880, 120), Vector2(880, 480),
			Vector2(1030, 240), Vector2(1180, 240), Vector2(1180, 480),
		]
	},
	{
		"nombre":      "Núcleo del Planeta",
		"fondo":       Color(0.25, 0.05, 0.05),
		"color_camino":Color(0.85, 0.30, 0.10),
		"puntos": [
			Vector2(-50, 360), Vector2(160, 360), Vector2(160, 160),
			Vector2(480, 160), Vector2(480, 560), Vector2(800, 560),
			Vector2(800, 160), Vector2(1120, 160), Vector2(1120, 360),
			Vector2(1330, 360)
		],
		"slots": [
			Vector2(60,  250), Vector2(320, 160), Vector2(320, 460),
			Vector2(640, 360), Vector2(640, 160), Vector2(640, 560),
			Vector2(960, 160), Vector2(960, 460), Vector2(1200, 250),
		]
	},
]

# ─── Fábrica pública ──────────────────────────────────────────────────────
static func build_map(idx_nivel: int) -> Node2D:
	var idx: int = clamp(idx_nivel, 0, DATOS_MAPAS.size() - 1)
	var datos: Dictionary = DATOS_MAPAS[idx] as Dictionary

	var raiz := Node2D.new()
	raiz.name = "Mapa_%d_%s" % [idx + 1, (datos["nombre"] as String).replace(" ", "")]

	_agregar_fondo(raiz, datos["fondo"] as Color)
	var puntos: PackedVector2Array = _empaquetar_vectores(datos["puntos"] as Array)
	_agregar_visual_camino(raiz, puntos, datos["color_camino"] as Color)
	_agregar_nodo_camino(raiz, puntos)
	_agregar_contenedor_enemigos(raiz)
	_agregar_slots_torres(raiz, _empaquetar_vectores(datos["slots"] as Array))
	_agregar_managers(raiz)
	_agregar_nucleo_energia(raiz, puntos[-1] + Vector2(40, 0))
	_agregar_decoraciones(raiz, datos)

	return raiz

# ─── Constructores de nodos ────────────────────────────────────────────────
static func _agregar_fondo(padre: Node2D, color: Color) -> void:
	var fondo := ColorRect.new()
	fondo.name          = "Background"
	fondo.anchor_right  = 1.0
	fondo.anchor_bottom = 1.0
	fondo.offset_right  = 1280.0
	fondo.offset_bottom = 720.0
	fondo.color         = color
	padre.add_child(fondo)

static func _agregar_visual_camino(padre: Node2D, pts: PackedVector2Array, color: Color) -> void:
	var capa := Node2D.new()
	capa.name = "PathLayer"
	padre.add_child(capa)

	# Línea exterior del camino
	var linea := Line2D.new()
	linea.name          = "PathVisual"
	linea.default_color = Color(color, 0.5)
	linea.width         = 44.0
	linea.joint_mode    = Line2D.LINE_JOINT_ROUND
	linea.points        = pts
	capa.add_child(linea)

	# Línea interior más clara
	var interior := Line2D.new()
	interior.default_color = Color(color, 0.3)
	interior.width         = 24.0
	interior.joint_mode    = Line2D.LINE_JOINT_ROUND
	interior.points        = pts
	capa.add_child(interior)

static func _agregar_nodo_camino(padre: Node2D, pts: PackedVector2Array) -> void:
	var nodo_camino := Node2D.new()
	nodo_camino.name = "EnemyPath"
	# Guardar waypoints como metadato para recuperación fácil
	nodo_camino.set_meta("waypoints", pts)
	for i in pts.size():
		var marcador := Node2D.new()
		marcador.name            = "Punto%d" % i
		marcador.global_position = pts[i]
		nodo_camino.add_child(marcador)
	padre.add_child(nodo_camino)

static func _agregar_contenedor_enemigos(padre: Node2D) -> void:
	var contenedor  := Node2D.new()
	contenedor.name = "EnemyContainer"
	padre.add_child(contenedor)

static func _agregar_slots_torres(padre: Node2D, posiciones: PackedVector2Array) -> void:
	var nodo_slots: Node2D = Node2D.new()
	nodo_slots.name = "TowerSlots"
	padre.add_child(nodo_slots)

	var script_slot: Script = load("res://scripts/TowerSlot.gd")
	for i in posiciones.size():
		var slot: TowerSlot = TowerSlot.new()
		slot.set_script(script_slot)
		slot.name     = "Slot%d" % (i + 1)
		slot.position = posiciones[i]
		nodo_slots.add_child(slot)

static func _agregar_managers(padre: Node2D) -> void:
	var wm  := Node.new()
	wm.name  = "WaveManager"
	wm.set_script(load("res://scripts/managers/WaveManager.gd"))
	padre.add_child(wm)

	var tm  := Node.new()
	tm.name  = "TowerManager"
	tm.set_script(load("res://scripts/managers/TowerManager.gd"))
	padre.add_child(tm)

static func _agregar_nucleo_energia(padre: Node2D, pos: Vector2) -> void:
	var nucleo := Node2D.new()
	nucleo.name     = "EnergyCore"
	nucleo.position = pos.clamp(Vector2(50, 50), Vector2(1230, 670))

	# Visual de círculo pulsante
	var interior := ColorRect.new()
	interior.size     = Vector2(40, 40)
	interior.position = Vector2(-20, -20)
	interior.color    = Color(0.2, 0.8, 1.0, 0.9)
	nucleo.add_child(interior)

	# Etiqueta
	var etiqueta := Label.new()
	etiqueta.text     = "⚡ NÚCLEO"
	etiqueta.position = Vector2(-20, -40)
	etiqueta.add_theme_font_size_override("font_size", 11)
	nucleo.add_child(etiqueta)

	padre.add_child(nucleo)

	# Animación de pulso
	var tween: Tween = nucleo.create_tween().set_loops()
	tween.tween_property(interior, "modulate", Color(0.5, 1.0, 1.0), 1.0)
	tween.tween_property(interior, "modulate", Color(0.2, 0.5, 1.0), 1.0)

static func _agregar_decoraciones(padre: Node2D, datos: Dictionary) -> void:
	# Objetos ambientales dispersos con color del tema del mapa
	var capa_deco := Node2D.new()
	capa_deco.name = "Decoraciones"
	padre.add_child(capa_deco)

	var rng := RandomNumberGenerator.new()
	rng.seed = hash(datos["nombre"] as String)

	var color: Color  = datos["fondo"] as Color
	var acento: Color = color.lightened(0.3)

	for i in 30:
		var rect := ColorRect.new()
		rect.size     = Vector2(rng.randf_range(4, 14), rng.randf_range(4, 14))
		rect.position = Vector2(rng.randf_range(0, 1280), rng.randf_range(0, 720))
		rect.color    = Color(acento, rng.randf_range(0.2, 0.6))
		rect.z_index  = -1
		capa_deco.add_child(rect)

# ─── Helpers ──────────────────────────────────────────────────────────────
static func _empaquetar_vectores(arr: Array) -> PackedVector2Array:
	var resultado := PackedVector2Array()
	for v in arr:
		resultado.append(v)
	return resultado
