## ObjectPool.gd
## Singleton de autoload que implementa un pool de objetos para proyectiles.
## Evita la costosa instanciación/eliminación cada frame reutilizando nodos.
extends Node

# Almacenamiento del pool: ruta_escena -> Array[Node]
var _pools: Dictionary = {}
var _padre_pool: Node

func _ready() -> void:
	_padre_pool = Node.new()
	_padre_pool.name = "ObjetosPooled"
	add_child(_padre_pool)

# ─── API pública ──────────────────────────────────────────────────────────────

## Obtiene un objeto del pool (o instancia uno nuevo si el pool está vacío).
func get_object(escena: PackedScene) -> Node:
	var clave: String = escena.resource_path
	if clave not in _pools:
		_pools[clave] = []

	var pool: Array = _pools[clave]
	for obj in pool:
		if not obj.visible and obj.is_inside_tree():
			obj.visible = true
			return obj

	# Pool agotado — crear nueva instancia
	var instancia: Node = escena.instantiate()
	_padre_pool.add_child(instancia)
	pool.append(instancia)
	return instancia

## Devuelve un objeto al pool (lo oculta en lugar de liberarlo).
func return_object(obj: Node) -> void:
	obj.visible = false
	# Resetear posición fuera de pantalla para no interferir con física
	if obj is Node2D:
		(obj as Node2D).position = Vector2(-9999, -9999)

## Pre-calienta el pool con N instancias de una escena.
func prewarm(escena: PackedScene, cantidad: int) -> void:
	for i in cantidad:
		var instancia: Node = escena.instantiate()
		instancia.visible = false
		_padre_pool.add_child(instancia)
		var clave: String = escena.resource_path
		if clave not in _pools:
			_pools[clave] = []
		_pools[clave].append(instancia)
